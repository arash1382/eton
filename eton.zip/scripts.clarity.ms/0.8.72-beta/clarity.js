/* clarity-js v0.8.72-beta: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t, e, n, a, i, r, o, u, c, l, s, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O, x, I, D, C, A, P, R, L, Y, j, X, W, H, q, U, z, F, V, B, J, K, G, Z, Q, $, tt, et, nt, at, it, rt, ot, ut, ct, lt, st, dt, ft, ht, pt, gt, vt, mt, yt, bt, wt, kt, St, Et, Tt, Nt, Mt, _t, Ot, xt, It, Dt, Ct, At, Pt, Rt, Lt, Yt, jt, Xt, Wt, Ht, qt, Ut, zt, Ft, Vt, Bt, Jt, Kt, Gt, Zt, Qt, $t, te, ee, ne, ae, ie, re, oe, ue, ce, le, se, de, fe, he, pe, ge, ve, me, ye, be, we, ke, Se, Ee, Te, Ne, Me, _e, Oe, xe, Ie, De, Ce, Ae, Pe, Re, Le, Ye, je, Xe, We, He, qe, Ue, ze, Fe, Ve, Be, Je, Ke, Ge, Ze, Qe, $e, tn, en, nn, an, rn, on, un, cn, ln, sn, dn, fn, hn, pn, gn, vn, mn, yn, bn, wn, kn, Sn, En, Tn, Nn, Mn, _n, On, xn, In, Dn, Cn, An = {
        projectId: null,
        delay: 1e3,
        lean: !1,
        lite: !1,
        track: !0,
        content: !0,
        drop: [],
        mask: [],
        unmask: [],
        regions: [],
        cookies: [],
        fraud: !0,
        checksum: [],
        report: null,
        upload: null,
        fallback: null,
        upgrade: null,
        action: null,
        dob: null,
        delayDom: !1,
        throttleDom: !0,
        conversions: !1,
        includeSubdomains: !0,
        modules: [],
        diagnostics: !1,
        restart: 250
    };

    function Pn(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }

    function Rn() {
        return performance.now() + performance.timeOrigin
    }

    function Ln(e) {
        var n, a, i;
        return void 0 === e && (e = null), n = 0 === t ? Rn() : t, a = e && e.timeStamp > 0 ? e.timeStamp : performance.now(), i = e && e.view ? e.view.performance.timeOrigin : performance.timeOrigin, Math.max(Math.round(a + i - n), 0)
    }

    function Yn(t, e) {
        var n, a, i, r;
        for (void 0 === e && (e = null), i = a = 5381, r = 0; r < t.length; r += 2) a = (a << 5) + a ^ t.charCodeAt(r), r + 1 < t.length && (i = (i << 5) + i ^ t.charCodeAt(r + 1));
        return n = Math.abs(a + 11579 * i), (e ? n % Math.pow(2, e) : n).toString(36)
    }

    function jn(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e, n, a, r = -1,
                                    o = 0,
                                    c = !1,
                                    l = !1,
                                    s = !1,
                                    d = null;
                                for (zn(), e = 0; e < t.length; e++) n = t.charCodeAt(e), c = c || n >= 48 && n <= 57, l = l || 64 === n, s = 9 === n || 10 === n || 13 === n || 32 === n, (0 === e || e === t.length - 1 || s) && ((c || l) && (null === d && (d = t.split("")), a = t.substring(r + 1, s ? e : e + 1), a = i && null !== u ? a.match(u) ? a : qn(a, "▪", "▫") : Hn(a), d.splice(r + 1 - o, a.length, a), o += a.length - 1), s && (c = !1, l = !1, r = e));
                                return d ? d.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return Un(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? Wn(t) : Hn(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                        case "href":
                        case "xlink:href":
                            return 3 === n ? (null == t ? void 0 : t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return Un(t);
                        case "placeholder":
                            return Hn(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? Wn(t) : Hn(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return qn(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function Xn(t, e, n) {
        var i, r, o;
        return void 0 === e && (e = !1), void 0 === n && (n = !1), i = t, e ? i = "https://Electron" : (r = An.drop) && r.length > 0 && t && t.indexOf("?") > 0 && (i = (o = t.split("?"))[0] + "?" + o[1].split("&").map((function(t) {
            return r.some((function(e) {
                return 0 === t.indexOf(e + "=")
            })) ? t.split("=")[0] + "=*na*" : t
        })).join("&")), n && (i = i.substring(0, a)), i
    }

    function Wn(t) {
        var e, n, a, i, r = t.trim();
        return r.length > 0 ? (e = r[0], n = t.indexOf(e), a = t.substr(0, n), i = t.substr(n + r.length), a + r.length.toString(36) + i) : t
    }

    function Hn(t) {
        return t.replace(n, "•")
    }

    function qn(t, e, n) {
        return zn(), t ? t.replace(o, e).replace(r, n) : t
    }

    function Un(t) {
        var e, n = 5 * (Math.floor(t.length / 5) + 1),
            a = "";
        for (e = 0; e < n; e++) a += e > 0 && e % 5 == 0 ? " " : "•";
        return a
    }

    function zn() {
        if (i && null === r) try {
            r = new RegExp("\\p{N}", "gu"), o = new RegExp("\\p{L}", "gu"), u = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            i = !1
        }
    }

    function Fn() {
        s && (c = {
            time: Ln(),
            event: 4,
            data: Object.assign({}, l)
        }), l = l || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0,
            modules: null
        }
    }

    function Vn(t, e, n, a) {
        switch (t) {
            case 8:
                l.docWidth = e, l.docHeight = n;
                break;
            case 11:
                l.screenWidth = e, l.screenHeight = n;
                break;
            case 10:
                l.scrollX = e, l.scrollY = n, l.scrollTime = a;
                break;
            case 12:
                l.moveX = e, l.moveY = n, l.moveTime = a, Bn(e, n, a);
                break;
            case 13:
                l.downX = e, l.downY = n, l.downTime = a, Bn(e, n, a);
                break;
            case 14:
                l.upX = e, l.upY = n, l.upTime = a, Bn(e, n, a);
                break;
            default:
                Bn(e, n, a)
        }
        s = !0
    }

    function Bn(t, e, n) {
        l.pointerPrevX = l.pointerX, l.pointerPrevY = l.pointerY, l.pointerPrevTime = l.pointerTime, l.pointerX = t, l.pointerY = e, l.pointerTime = n
    }

    function Jn(t) {
        l.activityTime = t
    }

    function Kn(t, e) {
        Mo() && t && "string" == typeof t && t.length < 255 && (d = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Br(24))
    }

    function Gn(t) {
        t in f || (f[t] = 0), t in h || (h[t] = 0)
    }

    function Zn(t) {
        Gn(t), f[t]++, h[t]++
    }

    function Qn(t, e) {
        null !== e && (Gn(t), f[t] += e, h[t] += e)
    }

    function $n(t, e) {
        null !== e && !1 === isNaN(e) && (t in f || (f[t] = 0), (e > f[t] || 0 === f[t]) && (h[t] = e, f[t] = e))
    }

    function ta(t, e, n) {
        return window.setTimeout(vo(t), e, n)
    }

    function ea(t) {
        return window.clearTimeout(t)
    }

    function na() {
        var t = Ln();
        p = {
            gap: t - g
        }, Br(25), p.gap < 3e5 ? m = ta(na, v) : fn && (Kn("clarity", "suspend"), Po(), ["mousemove", "touchstart"].forEach((function(t) {
            return mo(document, t, _o)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return mo(window, t, _o)
        })))
    }

    function aa(t, e, n, a) {
        return new(n || (n = Promise))((function(i, r) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    r(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    r(t)
                }
            }

            function c(t) {
                var e;
                t.done ? i(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function ia(t, e) {
        var n, a, i, r, o = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1]
            },
            trys: [],
            ops: []
        };
        return r = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
            return this
        }), r;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; r && (r = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (i = 2 & u[0] ? a.return : u[0] ? a.throw || ((i = a.return) && i.call(a), 0) : a.next) && !(i = i.call(a, u[1])).done) return i;
                        switch (a = 0, i && (u = [2 & u[0], i.value]), u[0]) {
                            case 0:
                            case 1:
                                i = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!((i = (i = o.trys).length > 0 && i[i.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!i || u[1] > i[0] && u[1] < i[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < i[1]) {
                                    o.label = i[1], i = u;
                                    break
                                }
                                if (i && o.label < i[2]) {
                                    o.label = i[2], o.ops.push(u);
                                    break
                                }
                                i[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = i = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }

    function ra(t) {
        return aa(this, void 0, void 0, (function() {
            var e, n;
            return ia(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), b ? (e = new ReadableStream({
                            start: function(e) {
                                return aa(this, void 0, void 0, (function() {
                                    return ia(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, new Response(e).arrayBuffer()]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function oa(t, e) {
        ua(t, "string" == typeof e ? [e] : e)
    }

    function ua(t, e) {
        var n, a;
        if (Mo() && t && e && "string" == typeof t && t.length < 255) {
            n = t in w ? w[t] : [];
            for (a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            w[t] = n
        }
    }

    function ca() {
        w = {}
    }

    function la(t) {
        return aa(this, void 0, void 0, (function() {
            var e;
            return ia(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function sa(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }

    function da(t) {
        var e, n, a, i, r, o, u, c, l, s, d;
        try {
            for (o in n = (e = t && t.length > 0 ? t.split(/ (.*)/) : [""])[0].split(/\|(.*)/), a = parseInt(n[0]), i = n.length > 1 ? n[1] : "", r = e.length > 1 ? JSON.parse(e[1]) : {}, E[a] = {}, T[a] = {}, N[a] = {}, M[a] = i, r) switch (u = parseInt(o), c = r[o], l = 2, c.startsWith("~") ? l = 0 : c.startsWith("!") && (l = 4), l) {
                case 0:
                    s = c.slice(1), E[a][u] = ga(s);
                    break;
                case 2:
                    T[a][u] = c;
                    break;
                case 4:
                    d = c.slice(1), N[a][u] = d
            }
        } catch (t) {
            Pr(8, 1, t ? t.name : null)
        }
    }

    function fa(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function ha() {
        S.clear()
    }

    function pa(t, e, n) {
        var a, i = !1;
        t in k || (k[t] = {}, i = !0), a = N[t], 0 == Object.keys(a).length || e in k[t] && k[t][e] == n || (i = !0), k[t][e] = n, i && S.add(t)
    }

    function ga(t) {
        for (var e, n, a, i, r = [], o = t.split("."); o.length > 0;) n = (e = o.shift()).indexOf("["), a = e.indexOf("{"), i = e.indexOf("}"), r.push({
            name: n > 0 ? e.slice(0, n) : a > 0 ? e.slice(0, a) : e,
            type: n > 0 ? 1 : a > 0 ? 2 : 3,
            condition: a > 0 ? e.slice(a + 1, i) : null
        });
        return r
    }

    function va(t, e) {
        var n, a, i, r, o, u, c, l;
        if (void 0 === e && (e = window), 0 == t.length) return e;
        if (n = t.shift(), e && e[n.name]) {
            if (i = e[n.name], 1 !== n.type && ma(i, n.condition)) a = va(t, i);
            else if (Array.isArray(i)) {
                for (r = [], o = 0, u = i; o < u.length; o++) ma(c = u[o], n.condition) && (l = va(t, c)) && r.push(l);
                a = r
            }
            return a
        }
        return null
    }

    function ma(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }

    function ya(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function ba(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }

    function wa(t, e) {
        var n, a, i, r, o, u, c;
        if (void 0 === e && (e = !1), ya(document, "cookie") && (a = document.cookie.split(";")))
            for (i = 0; i < a.length; i++)
                if ((r = a[i].split("=")).length > 1 && r[0] && r[0].trim() === t) {
                    for (u = (o = ba(r[1]))[0], c = o[1]; u;) u = (n = ba(c))[0], c = n[1];
                    return e ? c.endsWith("~1") ? c.substring(0, c.length - 2) : null : c
                }
        return null
    }

    function ka(t, e, n) {
        var a, i, r, o, u;
        if ((An.track || "" == e) && (navigator && navigator.cookieEnabled || ya(document, "cookie"))) {
            a = function(t) {
                return encodeURIComponent(t)
            }(e), (i = new Date).setDate(i.getDate() + n), r = t + "=" + a + ";" + (i ? "expires=" + i.toUTCString() : "") + ";path=/";
            try {
                if (null === _) {
                    for (u = (o = location.hostname ? location.hostname.split(".") : []).length - 1; u >= 0; u--)
                        if (_ = "." + o[u] + (_ || ""), u < o.length - 1 && (document.cookie = r + ";domain=" + _, wa(t) === e)) return;
                    _ = ""
                }
            } catch (t) {
                _ = ""
            }
            document.cookie = _ ? r + ";domain=" + _ : r
        }
    }

    function Sa(t) {
        try {
            x && JSON.parse(t).forEach((function(t) {
                return x(t)
            }))
        } catch (t) {}
    }

    function Ea(t, e, n) {
        An.fraud && null !== t && n && n.length >= 5 && (C = {
            id: t,
            target: e,
            checksum: Yn(n, 28)
        }, D.includes(C.checksum) || (D.push(C.checksum), Ar(41)))
    }

    function Ta(t) {
        var e, n, a = yr(t);
        a && (n = (e = a.value) && e.length >= 5 && An.fraud && !R.includes(a.type) ? Yn(e, 28) : "", j.push({
            time: Ln(t),
            event: 42,
            data: {
                target: yr(t),
                type: a.type,
                value: e,
                checksum: n
            }
        }), Lr(wr.bind(this, 42)))
    }

    function Na() {
        j = []
    }

    function Ma(t) {
        var e, n, a = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                n = null === (e = t.offsetParent) ? er(t.ownerDocument) : null, a.x += t.offsetLeft, a.y += t.offsetTop, t = n || e
            } while (t);
        return a
    }

    function _a(t, e, n) {
        var a, i, r, o, u, c, l, s, d, f, h = er(e),
            p = h && h.contentDocument ? h.contentDocument.documentElement : document.documentElement,
            g = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + p.scrollLeft) : null,
            v = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + p.scrollTop) : null;
        h && (a = Ma(h), g = g ? g + Math.round(a.x) : g, v = v ? v + Math.round(a.y) : v), r = function(t) {
            for (; t && t !== document;) {
                if (t.nodeType === Node.ELEMENT_NODE) {
                    var e = t;
                    if ("A" === e.tagName) return e
                }
                t = t.parentNode
            }
            return null
        }(i = yr(n)), o = xa(i), 0 === n.detail && o && (g = Math.round(o.x + o.w / 2), v = Math.round(o.y + o.h / 2)), u = function(t, e, n, a) {
            if (!a) return {
                eX: 0,
                eY: 0
            };
            for (var i = a, r = t, o = Math.max(Math.floor((e - i.x) / i.w * 32767), 0), u = Math.max(Math.floor((n - i.y) / i.h * 32767), 0), c = 0;
                (o > 32767 || u > 32767) && r.parentElement && c < 10;) c++, (i = xa(r = r.parentElement)) && (o = Math.max(Math.floor((e - i.x) / i.w * 32767), 0), u = Math.max(Math.floor((n - i.y) / i.h * 32767), 0));
            return {
                eX: o,
                eY: u
            }
        }(i, g, v, o), c = u.eX, l = u.eY, null !== g && null !== v && (s = function(t) {
            var e, n, a = null,
                i = !1;
            return t && (e = t.textContent || String(t.value || "") || t.alt) && (i = (a = (n = e.replace(/\s+/g, " ").trim()).substring(0, 25)).length === n.length), {
                text: a,
                isFullText: i ? 1 : 0
            }
        }(i), H.push({
            time: Ln(n),
            event: t,
            data: {
                target: i,
                x: g,
                y: v,
                eX: c,
                eY: l,
                button: n.button,
                reaction: (d = i, f = Oa(d, "tagName"), X.includes(f) ? 0 : 1),
                context: Ia(r),
                text: s.text,
                link: r ? r.href : null,
                hash: null,
                trust: n.isTrusted ? 1 : 0,
                isFullText: s.isFullText,
                w: o ? o.w : 0,
                h: o ? o.h : 0,
                tag: Oa(i, "tagName").substring(0, 10),
                class: Oa(i, "className").substring(0, 50),
                id: Oa(i, "id").substring(0, 25),
                source: An.diagnostics && !n.isTrusted ? Da() : 0
            }
        }), Lr(wr.bind(this, t)))
    }

    function Oa(t, e) {
        var n;
        return t.nodeType === Node.ELEMENT_NODE && "string" == typeof(n = null == t ? void 0 : t[e]) ? null == n ? void 0 : n.toLowerCase() : ""
    }

    function xa(t) {
        var e, n, a, i, r, o = null,
            u = t.ownerDocument || document,
            c = u.documentElement,
            l = u.defaultView || window;
        return "function" == typeof t.getBoundingClientRect && (e = t.getBoundingClientRect()) && e.width > 0 && e.height > 0 && (n = "pageXOffset" in l ? l.pageXOffset : c.scrollLeft, a = "pageYOffset" in l ? l.pageYOffset : c.scrollTop, o = {
            x: Math.floor(e.left + n),
            y: Math.floor(e.top + a),
            w: Math.floor(e.width),
            h: Math.floor(e.height)
        }, (i = er(u)) && (r = Ma(i), o.x += Math.round(r.x), o.y += Math.round(r.y))), o
    }

    function Ia(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function Da() {
        var t, e, n, a, i, r;
        Da.dn = 1;
        try {
            for (t = (new Error).stack || "", e = location.origin, n = 4, a = 0, i = t.split("\n"); a < i.length; a++)(r = i[a]).includes("://") ? n = !r.includes("extension") && r.includes(e) ? 1 : 2 : (r.includes("eval") || r.includes("Function") || r.includes("<a") || W.test(r)) && (n = 3);
            return n
        } catch (t) {
            return 4
        }
    }

    function Ca() {
        H = []
    }

    function Aa(t, e) {
        q.push({
            time: Ln(e),
            event: 38,
            data: {
                target: yr(e),
                action: t
            }
        }), Lr(wr.bind(this, 38))
    }

    function Pa() {
        q = []
    }

    function Ra(t) {
        var e, n, a, i = yr(t),
            r = or(i);
        if (i && i.type && r) {
            switch (e = i.value, n = i.type, i.type) {
                case "radio":
                case "checkbox":
                    e = i.checked ? "true" : "false"
            }
            a = {
                target: i,
                value: e,
                type: n,
                trust: t.isTrusted ? 1 : 0
            }, z.length > 0 && z[z.length - 1].data.target === a.target && z.pop(), z.push({
                time: Ln(t),
                event: 27,
                data: a
            }), ea(U), U = ta(Ya, 750, 27)
        }
    }

    function La(t) {
        "Enter" === t.key && !t.repeat && z.length > 0 && (ea(U), Ya(27))
    }

    function Ya(t) {
        Lr(wr.bind(this, t))
    }

    function ja() {
        z = []
    }

    function Xa(t) {
        mo(t, "mousedown", Ha.bind(this, 13, t), !0), mo(t, "mouseup", Ha.bind(this, 14, t), !0), mo(t, "mousemove", Ha.bind(this, 12, t), !0), mo(t, "wheel", Ha.bind(this, 15, t), !0), mo(t, "dblclick", Ha.bind(this, 16, t), !0), An.diagnostics && mo(t, "pointerdown", Wa.bind(this, t), !0), mo(t, "touchstart", Ua.bind(this, 17, t), !0), mo(t, "touchend", Ua.bind(this, 18, t), !0), mo(t, "touchmove", Ua.bind(this, 19, t), !0), mo(t, "touchcancel", Ua.bind(this, 20, t), !0)
    }

    function Wa(t, e) {
        var n = function(t) {
                switch (t) {
                    case "mouse":
                        return 1;
                    case "touch":
                        return 2;
                    case "pen":
                        return 3;
                    default:
                        return 0
                }
            }(e.pointerType),
            a = qa(t, e),
            i = a[0],
            r = a[1];
        null !== i && null !== r && za({
            time: Ln(e),
            event: 53,
            data: {
                target: yr(e),
                x: i,
                y: r,
                id: e.pointerId,
                isPrimary: e.isPrimary,
                type: n,
                pressure: e.pressure,
                width: e.width,
                height: e.height
            }
        })
    }

    function Ha(t, e, n) {
        var a, i = qa(e, n),
            r = i[0],
            o = i[1];
        null !== r && null !== o && (a = {
            target: yr(n),
            x: r,
            y: o
        }, za({
            time: Ln(n),
            event: t,
            data: a
        }))
    }

    function qa(t, e) {
        var n, a = er(t),
            i = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            r = "pageX" in e ? Math.round(e.pageX) : "clientX" in e ? Math.round(e.clientX + i.scrollLeft) : null,
            o = "pageY" in e ? Math.round(e.pageY) : "clientY" in e ? Math.round(e.clientY + i.scrollTop) : null;
        return a && (n = Ma(a), r = null !== r ? r + Math.round(n.x) : r, o = null !== o ? o + Math.round(n.y) : o), [r, o]
    }

    function Ua(t, e, n) {
        var a, i, r, o, u, c, l = er(e),
            s = l && l.contentDocument ? l.contentDocument.documentElement : document.documentElement,
            d = n.changedTouches,
            f = Ln(n);
        if (d)
            for (a = 0; a < d.length; a++) {
                switch (r = "clientX" in (i = d[a]) ? Math.round(i.clientX + s.scrollLeft) : null, o = "clientY" in i ? Math.round(i.clientY + s.scrollTop) : null, r = r && l ? r + Math.round(l.offsetLeft) : r, o = o && l ? o + Math.round(l.offsetTop) : o, u = "identifier" in i ? i.identifier : void 0, t) {
                    case 17:
                        0 === K.size && (B = !0, J = u), K.add(u);
                        break;
                    case 18:
                    case 20:
                        K.delete(u)
                }
                c = B && J === u, null !== r && null !== o && za({
                    time: f,
                    event: t,
                    data: {
                        target: yr(n),
                        x: r,
                        y: o,
                        id: u,
                        isPrimary: c
                    }
                }), 20 !== t && 18 !== t || J === u && (B = !1)
            }
    }

    function za(t) {
        var e, n;
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                (n = (e = F.length) > 1 ? F[e - 2] : null) && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        i = Math.sqrt(n * n + a * a),
                        r = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && i < 20 && r < 25 && u
                }(n, t) && F.pop(), F.push(t), ea(V), V = ta(Fa, 500, t.event);
                break;
            default:
                F.push(t), Fa(t.event)
        }
    }

    function Fa(t) {
        Lr(wr.bind(this, t))
    }

    function Va() {
        F = []
    }

    function Ba(t, e) {
        var n = 0,
            a = null,
            i = null;

        function r() {
            var r, o, u, c = this,
                l = [];
            for (r = 0; r < arguments.length; r++) l[r] = arguments[r];
            if (u = (o = performance.now()) - n, 0 !== n && u < e) {
                if (i = l, a) return;
                a = setTimeout((function() {
                    n = performance.now(), t.apply(c, i), i = null, a = null
                }), e - u)
            } else n = o, t.apply(this, l)
        }
        return r.cleanup = function() {
            a && (clearTimeout(a), a = null, i = null)
        }, r
    }

    function Ja() {
        var t = document.documentElement;
        G = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, Q ? (ea(Z), Z = ta(Ka, 500, 11)) : (wr(11), Q = !0)
    }

    function Ka(t) {
        Lr(wr.bind(this, t))
    }

    function Ga() {
        G = null, ea(Z), $.cleanup()
    }

    function Za(t) {
        var e, n, a, i, r, o, u, c, l, s, d, f, h, p, g, v, m;
        if (void 0 === t && (t = null), e = window, n = document.documentElement, a = t ? yr(t) : n) {
            if (a && a.nodeType === Node.DOCUMENT_NODE && (e = (i = er(a)) ? i.contentWindow : e, a = n = a.documentElement), r = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft), o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop), u = window.innerWidth, d = (c = window.innerHeight) - (s = u > c ? .15 * c : .2 * c), f = Qa(l = u / 3, s), h = Qa(l, d), p = t && t.isTrusted ? 1 : 0, g = {
                    time: Ln(t),
                    event: 10,
                    data: {
                        target: a,
                        x: r,
                        y: o,
                        top: f,
                        bottom: h,
                        trust: p
                    }
                }, null === t && 0 === r && 0 === o || null === r || null === o) return et = f, void(nt = h);
            (m = (v = tt.length) > 1 ? tt[v - 2] : null) && function(t, e) {
                var n = t.data.x - e.data.x,
                    a = t.data.y - e.data.y;
                return n * n + a * a < 400 && e.time - t.time < 50
            }(m, g) && tt.pop(), tt.push(g), ea(at), at = ta($a, 500, 10)
        }
    }

    function Qa(t, e) {
        var n, a, i;
        return "caretPositionFromPoint" in document ? i = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (i = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), i || (i = document.elementFromPoint(t, e)), i && i.nodeType === Node.TEXT_NODE && (i = i.parentNode), i
    }

    function $a(t) {
        Lr(wr.bind(this, t))
    }

    function ti() {
        var t, e, n, a;
        et && Kr(31, null === (t = null == (n = br(et, null)) ? void 0 : n.hash) || void 0 === t ? void 0 : t.join(".")), nt && Kr(32, null === (e = null == (a = br(nt, null)) ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
    }

    function ei(t) {
        var e, n = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        null !== n && (null === n.anchorNode && null === n.focusNode || n.anchorNode === n.focusNode && n.anchorOffset === n.focusOffset || (e = rt.start ? rt.start : null, null !== ot && null !== rt.start && e !== n.anchorNode && (ea(ut), ni(21)), rt = {
            start: n.anchorNode,
            startOffset: n.anchorOffset,
            end: n.focusNode,
            endOffset: n.focusOffset
        }, ot = n, ea(ut), ut = ta(ni, 500, 21)))
    }

    function ni(t) {
        Lr(wr.bind(this, t))
    }

    function ai() {
        ot = null, rt = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }

    function ii(t) {
        ct.push({
            time: Ln(t),
            event: 39,
            data: {
                target: yr(t)
            }
        }), Lr(wr.bind(this, 39))
    }

    function ri() {
        ct = []
    }

    function oi(t) {
        lt = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, wr(26, Ln(t)), Po()
    }

    function ui() {
        lt = null
    }

    function ci(t) {
        if (void 0 === t && (t = null), "visibilityState" in document) {
            var e = "visible" === document.visibilityState ? 1 : 0;
            st = {
                visible: e
            }, wr(28, Ln(t))
        }
    }

    function li() {
        st = null
    }

    function si() {
        dt = null
    }

    function di(t) {
        dt = {
            focused: t
        }, wr(50)
    }

    function fi(t) {
        t && t.persisted && (Ao(), Pr(11, 0))
    }

    function hi(t) {
        var e, n, a, i = [],
            r = {},
            o = 0,
            u = null;
        for (e = 0; e < t.length; e++) "string" == typeof t[e] ? (a = r[n = t[e]] || -1) >= 0 ? u ? u.push(a) : (u = [a], i.push(u), o++) : (u = null, i.push(n), r[n] = o++) : (u = null, i.push(t[e]), o++);
        return i
    }

    function pi(t) {
        An.lean && An.lite || null == t || (t.__clr = t.__clr || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (gi(t, "replace", 1), gi(t, "replaceSync", 2)))
    }

    function gi(t, e, n) {
        void 0 === t.__clr[e] && (t.__clr[e] = t.CSSStyleSheet.prototype[e], t.CSSStyleSheet.prototype[e] = function() {
            return Mo() && bt.includes(this[gt]) && bi(Ln(), this[gt], n, arguments[0]), t.__clr[e].apply(this, arguments)
        })
    }

    function vi() {
        pi(window)
    }

    function mi(t, e) {
        var n, a, i, r, o, u, c;
        if ((!An.lean || !An.lite) && (yt.includes(t) || (yt.push(t), t.defaultView && pi(t.defaultView)), e = e || Ln(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (n = [], a = 0, i = t.adoptedStyleSheets; a < i.length; a++)(r = i[a])[gt] && bt.includes(r[gt]) || (r[gt] = so(), bt.push(r[gt]), bi(e, r[gt], 0), bi(e, r[gt], 2, Bi(r))), n.push(r[gt]);
            o = Qi(t, !0), vt[o] || (vt[o] = []), u = n, c = vt[o], u.length === c.length && u.every((function(t, e) {
                return t === c[e]
            })) || (function(t, e, n, a) {
                pt.push({
                    time: t,
                    event: 45,
                    data: {
                        id: e,
                        operation: 3,
                        newIds: a
                    }
                }), Mi(45)
            }(e, t == document ? -1 : Qi(t), 0, n), vt[o] = n, mt[o] = e)
        }
    }

    function yi() {
        pt = [], ht = []
    }

    function bi(t, e, n, a) {
        ht.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), Mi(46)
    }

    function wi() {
        wt = []
    }

    function ki(t, e, n, a, i, r, o) {
        wt.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: i,
                targetId: r,
                timeline: o
            }
        }), Mi(44)
    }

    function Si(t) {
        var e = Animation.prototype[t];
        "function" == typeof e && (Animation.prototype[t] = function() {
            return Ei(this, t), e.apply(this, arguments)
        })
    }

    function Ei(t, e) {
        var n, a, i, r, o;
        if (Mo() && (a = (null == (n = t.effect) ? void 0 : n.target) ? Qi(n.target) : null, n && null !== a && !n.pseudoElement && n.getKeyframes && n.getTiming && (t[Et] || (t[Et] = so(), t[Tt] = 0, i = n.getKeyframes(), r = n.getTiming(), ki(Ln(), t[Et], 0, JSON.stringify(i), JSON.stringify(r), a)), t[Tt]++ < Nt))) {
            switch (o = null, e) {
                case "play":
                    o = 1;
                    break;
                case "pause":
                    o = 2;
                    break;
                case "cancel":
                    o = 3;
                    break;
                case "finish":
                    o = 4;
                    break;
                case "commitStyles":
                    o = 5
            }
            o && ki(Ln(), t[Et], o)
        }
    }

    function Ti(t) {
        _t.has(t) || (_t.add(t), Mt.push(t), Lr(Mi.bind(this, 51)))
    }

    function Ni() {
        Mt.length = 0
    }

    function Mi(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), aa(this, void 0, void 0, (function() {
            var a, i, r, o, u, c, l, s, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O, x, I, D, C, A, P;
            return ia(this, (function(R) {
                switch (R.label) {
                    case 0:
                        switch (a = n || Ln(), i = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5];
                            case 51:
                                return [3, 12]
                        }
                        return [3, 13];
                    case 1:
                        return r = Ot, i.push(r.width, r.height), Vn(t, r.width, r.height), _r(i), [3, 13];
                    case 2:
                        for (o = 0, u = se; o < u.length; o++) c = u[o], (i = [c.time, 7]).push(c.data.id, c.data.interaction, c.data.visibility, c.data.name), _r(i, !1);
                        return mr(), [3, 13];
                    case 3:
                        for (l = 0, s = pt; l < s.length; l++) g = s[l], (i = [g.time, g.event]).push(g.data.id, g.data.operation, g.data.newIds), _r(i);
                        for (d = 0, f = ht; d < f.length; d++) g = f[d], (i = [g.time, g.event]).push(g.data.id, g.data.operation, g.data.cssRules), _r(i, !1);
                        return yi(), [3, 13];
                    case 4:
                        for (h = 0, p = wt; h < p.length; h++) g = p[h], (i = [g.time, g.event]).push(g.data.id, g.data.operation, g.data.keyFrames, g.data.timing, g.data.timeline, g.data.targetId), _r(i);
                        return wi(), [3, 13];
                    case 5:
                        if (2 === jr(e)) return [3, 13];
                        if (v = function() {
                                var t, e, n, a;
                                for (t = [], e = 0, n = Zt; e < n.length; e++)(a = n[e]) in Gt && t.push(Gt[a]);
                                return Zt = [], t
                            }(), !(v.length > 0)) return [3, 11];
                        m = 0, y = v, R.label = 6;
                    case 6:
                        return m < y.length ? (b = y[m], 0 !== (w = jr(e)) ? [3, 8] : [4, Hr(e)]) : [3, 10];
                    case 7:
                        w = R.sent(), R.label = 8;
                    case 8:
                        if (2 === w) return [3, 10];
                        for (k = b.data, S = b.metadata.active, E = b.metadata.suspend, T = b.metadata.privacy, N = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(b), M = 0, _ = S ? ["tag", "attributes", "value"] : ["tag"]; M < _.length; M++)
                            if (k[O = _[M]] || "" === k[O]) switch (O) {
                                case "tag":
                                    x = _i(b), I = N ? -1 : 1, i.push(b.id * I), b.parent && S && (i.push(b.parent), b.previous && i.push(b.previous)), i.push(E ? "*M" : k[O]), x && 2 === x.length && i.push("#" + x[0].toString(36) + "." + x[1].toString(36));
                                    break;
                                case "attributes":
                                    for (D in k[O]) void 0 !== k[O][D] && i.push(Oi(D, k[O][D], T, k.tag));
                                    break;
                                case "value":
                                    Ea(b.metadata.fraud, b.id, k[O]), i.push(jn(k[O], k.tag, T, N))
                            }
                        R.label = 9;
                    case 9:
                        return m++, [3, 6];
                    case 10:
                        6 === t && Jn(a), _r(hi(i), !An.lean), R.label = 11;
                    case 11:
                        return [3, 13];
                    case 12:
                        for (C = 0, A = Mt; C < A.length; C++) P = A[C], _r([a, 51, P]);
                        return Ni(), [3, 13];
                    case 13:
                        return [2]
                }
            }))
        }))
    }

    function _i(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = rr(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function Oi(t, e, n, a) {
        return "href" === t && "LINK" === a ? t + "=" + e : t + "=" + jn(e, 0 === t.indexOf("data-") ? "data-" : t, n)
    }

    function xi() {
        Ot = null
    }

    function Ii() {
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            i = t ? t.offsetWidth : null,
            r = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, i, r, o, u),
            l = t ? t.clientHeight : null,
            s = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            h = e ? e.scrollHeight : null,
            p = e ? e.offsetHeight : null,
            g = Math.max(l, s, d, f, h, p);
        null !== Ot && c === Ot.width && g === Ot.height || null === c || null === g || (Ot = {
            width: c,
            height: g
        }, Mi(8))
    }

    function Di(t, e, n, a) {
        return aa(this, void 0, void 0, (function() {
            var i, r, o, u, c;
            return ia(this, (function(l) {
                switch (l.label) {
                    case 0:
                        i = [t], l.label = 1;
                    case 1:
                        if (!(i.length > 0)) return [3, 4];
                        for (r = i.shift(), o = r.firstChild; o;) i.push(o), o = o.nextSibling;
                        return 0 !== (u = jr(e)) ? [3, 3] : [4, Hr(e)];
                    case 2:
                        u = l.sent(), l.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = zi(r, n, a)) && i.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }

    function Ci() {
        xt = new Set, Ct = [], At = null, Rt = 0, Lt = {}, Yt = new WeakMap, Wi(window)
    }

    function Ai(t) {
        var e = Ln();
        ! function(t, e) {
            var n, a;
            6 in y ? e - (a = (n = y[6])[n.length - 1])[0] > 100 ? y[6].push([e, 0]) : a[1] = e - a[0] : y[6] = [
                [e, 0]
            ]
        }(0, e), It.push({
            time: e,
            mutations: t
        }), Lr(Ri, 1).then((function() {
            ta(Ii), vo(hr)()
        }))
    }

    function Pi(t, e, n, a) {
        return aa(this, void 0, void 0, (function() {
            var i, r, o;
            return ia(this, (function(u) {
                switch (u.label) {
                    case 0:
                        return 0 !== (i = jr(t)) ? [3, 2] : [4, Hr(t)];
                    case 1:
                        i = u.sent(), u.label = 2;
                    case 2:
                        if (2 === i) return [2];
                        switch (r = e.target, o = An.throttleDom ? function(t, e, n, a) {
                            var i, r, o, u, c, l = t.target ? or(t.target.parentNode) : null;
                            return l && "HTML" !== l.data.tag && (i = a > Rt, o = (r = or(t.target)) && r.selector ? r.selector.join() : t.target.nodeName, u = [l.selector ? l.selector.join() : "", o, t.attributeName, Li(t.addedNodes), Li(t.removedNodes)].join(), Lt[u] = u in Lt ? Lt[u] : [0, n], c = Lt[u], !1 === i && c[0] >= 10 && Yi(c[2], 2, e, a), c[0] = i ? c[1] === n ? c[0] : c[0] + 1 : 1, c[1] = n, c[0] >= 10) ? (c[2] = t.removedNodes, n > a + 3e3 ? t.type : (Dt[u] = {
                                mutation: t,
                                timestamp: a
                            }, "throttle")) : t.type
                        }(e, t, n, a) : e.type, o && r && r.ownerDocument && Zi(r.ownerDocument), o && r && r.nodeType == Node.DOCUMENT_FRAGMENT_NODE && r.host && Zi(r), o) {
                            case "attributes":
                                jt.includes(e.attributeName) || zi(r, 3, a);
                                break;
                            case "characterData":
                                zi(r, 4, a);
                                break;
                            case "childList":
                                Yi(e.addedNodes, 1, t, a), Yi(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function Ri() {
        return aa(this, void 0, void 0, (function() {
            var t, e, n, a, i, r, o, u, c, l, s;
            return ia(this, (function(d) {
                switch (d.label) {
                    case 0:
                        Xr(t = {
                            id: eo(),
                            cost: 3
                        }), d.label = 1;
                    case 1:
                        if (!(It.length > 0)) return [3, 7];
                        e = It.shift(), n = Ln(), a = 0, i = e.mutations, d.label = 2;
                    case 2:
                        return a < i.length ? (r = i[a], [4, Pi(t, r, n, e.time)]) : [3, 5];
                    case 3:
                        d.sent(), d.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, Mi(6, t, e.time)];
                    case 6:
                        return d.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(Dt), d.label = 8;
                    case 8:
                        return u < c.length ? (l = c[u], s = Dt[l], delete Dt[l], [4, Pi(t, s.mutation, Ln(), s.timestamp)]) : [3, 11];
                    case 9:
                        d.sent(), o = !0, d.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(Dt).length > 0 && (Pt && ea(Pt), Pt = ta((function() {
                            Lr(Ri, 1)
                        }), 33)), 0 === Object.keys(Dt).length && o ? [4, Mi(6, t, Ln())] : [3, 13];
                    case 12:
                        d.sent(), d.label = 13;
                    case 13:
                        return function() {
                            var t, e, n, a = Ln();
                            for (Object.keys(Lt).length > 1e4 && (Lt = {}, Zn(38)), t = 0, e = Object.keys(Lt); t < e.length; t++) n = e[t], a > Lt[n][1] + 3e4 && delete Lt[n]
                        }(), Wr(t), [2]
                }
            }))
        }))
    }

    function Li(t) {
        var e, n = [];
        for (e = 0; t && e < t.length; e++) n.push(t[e].nodeName);
        return n.join()
    }

    function Yi(t, e, n, a) {
        return aa(this, void 0, void 0, (function() {
            var i, r, o, u;
            return ia(this, (function(c) {
                switch (c.label) {
                    case 0:
                        i = t ? t.length : 0, r = 0, c.label = 1;
                    case 1:
                        return r < i ? (o = t[r], 1 !== e ? [3, 2] : (Di(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = jr(n)) ? [3, 4] : [4, Hr(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        zi(o, e, a), c.label = 5;
                    case 5:
                        return r++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function ji(t) {
        return Ct.includes(t) || Ct.push(t), At && ea(At), At = ta((function() {
            ! function() {
                var t, e, n, a;
                for (t = 0, e = Ct; t < e.length; t++)
                    if (n = e[t]) {
                        if ((a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE) && ur(n)) continue;
                        Xi(n, a ? "childList" : "characterData")
                    }
                Ct = []
            }()
        }), 33), t
    }

    function Xi(t, e) {
        vo(Ai)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function Wi(t) {
        if (null != t && (t.__clr = t.__clr || {}, Hi(t, "CSSStyleSheet", "InsertRule", "insertRule", (function() {
                return this.ownerNode
            })), Hi(t, "CSSStyleSheet", "DeleteRule", "deleteRule", (function() {
                return this.ownerNode
            })), Hi(t, "CSSMediaRule", "MediaInsertRule", "insertRule", (function() {
                return this.parentStyleSheet.ownerNode
            })), Hi(t, "CSSMediaRule", "MediaDeleteRule", "deleteRule", (function() {
                return this.parentStyleSheet.ownerNode
            })), "Element" in t && t.Element && t.Element.prototype && void 0 === t.__clr.AttachShadow)) {
            t.__clr.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return Mo() ? ji(t.__clr.AttachShadow.apply(this, arguments)) : t.__clr.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.__clr.AttachShadow = null
            }
        }
    }

    function Hi(t, e, n, a, i) {
        e in t && t[e] && t[e].prototype && void 0 === t.__clr[n] && (t.__clr[n] = t[e].prototype[a], t[e].prototype[a] = function() {
            return Mo() && ji(i.call(this)), t.__clr[n].apply(this, arguments)
        })
    }

    function qi(t) {
        var e, n, a, i;
        for (e = 0, n = Object.keys(t); e < n.length; e++) {
            if (i = t[a = n[e]], "@type" === a && "string" == typeof i) switch (i = (i = i.toLowerCase()).includes("article") || i.includes("posting") ? "article" : i) {
                case "article":
                case "recipe":
                    Kr(5, t[a]), Kr(8, t.creator), Kr(18, t.headline);
                    break;
                case "product":
                    Kr(5, t[a]), Kr(10, t.name), Kr(12, t.sku), t.brand && Kr(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && ($n(11, Ui(t.ratingValue, 100)), $n(18, Ui(t.bestRating)), $n(19, Ui(t.worstRating))), $n(12, Ui(t.ratingCount)), $n(17, Ui(t.reviewCount));
                    break;
                case "offer":
                    Kr(7, t.availability), Kr(14, t.itemCondition), Kr(13, t.priceCurrency), Kr(12, t.sku), $n(13, Ui(t.price));
                    break;
                case "brand":
                    Kr(6, t.name)
            }
            null !== i && "object" == typeof i && qi(i)
        }
    }

    function Ui(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(Xt, "")) * e)
        }
        return null
    }

    function zi(t, e, n) {
        var a, i, r, o, u, c, l, s, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O = null;
        if (2 === e && !1 === ur(t)) return O;
        switch (0 !== e && t.nodeType === Node.TEXT_NODE && t.parentElement && "STYLE" === t.parentElement.tagName && (t = t.parentNode), i = ur(t) ? tr : $i, r = t.parentElement ? t.parentElement : null, o = t.ownerDocument !== document, t.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                i(t, r = o && t.parentNode ? er(t.parentNode) : r, {
                    tag: (o ? "iframe:" : "") + "*D",
                    attributes: {
                        name: (u = t).name ? u.name : "HTML",
                        publicId: u.publicId,
                        systemId: u.systemId
                    }
                }, e);
                break;
            case Node.DOCUMENT_NODE:
                t === document && Zi(document), mi(t, n), Fi(t);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                (c = t).host && (Zi(c), "function" == typeof c.constructor && c.constructor.toString().includes("[native code]") ? (Fi(c), l = {
                    tag: "*S",
                    attributes: {
                        style: ""
                    }
                }, i(t, c.host, l, e)) : i(t, c.host, {
                    tag: "*P",
                    attributes: {}
                }, e), mi(t, n));
                break;
            case Node.TEXT_NODE:
                r = r || t.parentNode, (i === tr || r && ur(r) && "STYLE" !== r.tagName && "NOSCRIPT" !== r.tagName) && i(t, r, {
                    tag: "*T",
                    value: t.nodeValue
                }, e);
                break;
            case Node.ELEMENT_NODE:
                switch (d = (s = t).tagName, f = function(t) {
                    var e, n, a = {},
                        i = t.attributes;
                    if (i && i.length > 0)
                        for (e = 0; e < i.length; e++) n = i[e].name, zt.includes(n) || (a[n] = i[e].value);
                    return "INPUT" === t.tagName && !("value" in a) && t.value && (a.value = t.value), a
                }(s), h = f.id, r = t.parentElement ? t.parentElement : t.parentNode ? t.parentNode : null, h && function(t, e) {
                    var n = function(t, e) {
                        if (e === document.body) switch (t) {
                            case Wt:
                                return 1;
                            case Ht:
                                return 5
                        } else if (e === document.documentElement) switch (t) {
                            case qt:
                                return 6;
                            case Ut:
                                return 7
                        }
                        return 0
                    }(t, e);
                    0 !== n && Kr(39, n.toString())
                }(h, r), "http://www.w3.org/2000/svg" === s.namespaceURI && (d = "svg:" + d), d) {
                    case "HTML":
                        i(t, r = o && r ? er(r) : r, {
                            tag: (o ? "iframe:" : "") + d,
                            attributes: f
                        }, e);
                        break;
                    case "SCRIPT":
                        if ("type" in f && "application/ld+json" === f.type) try {
                            qi(JSON.parse(s.text.replace(Ft, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        i(t, r, {
                            tag: d,
                            attributes: {},
                            value: ""
                        }, e);
                        break;
                    case "META":
                        if ((p = "property" in f ? "property" : "name" in f ? "name" : null) && "content" in f) switch (g = f.content, f[p]) {
                            case "og:title":
                                Kr(20, g);
                                break;
                            case "og:type":
                                Kr(19, g);
                                break;
                            case "generator":
                                Kr(21, g)
                        }
                        break;
                    case "HEAD":
                        v = {
                            tag: d,
                            attributes: f
                        }, m = o && (null === (a = t.ownerDocument) || void 0 === a ? void 0 : a.location) ? t.ownerDocument.location : location, v.attributes["*B"] = m.protocol + "//" + m.host + m.pathname, i(t, r, v, e);
                        break;
                    case "BASE":
                        (y = or(t.parentElement)) && ((b = document.createElement("a")).href = f.href, y.data.attributes["*B"] = b.protocol + "//" + b.host + b.pathname);
                        break;
                    case "STYLE":
                        i(t, r, {
                            tag: d,
                            attributes: f,
                            value: (N = s, M = N.textContent ? N.textContent.trim() : "", _ = N.dataset ? Object.keys(N.dataset).length : 0, (0 === M.length || _ > 0 || N.id.length > 0) && (M = Bi(N.sheet)), M)
                        }, e);
                        break;
                    case "IFRAME":
                        k = {
                                tag: d,
                                attributes: f
                            },
                            function(t) {
                                var e, n = !1;
                                if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
                                    e = t;
                                    try {
                                        e.contentDocument && (oe.set(e.contentDocument, e), ue.set(e, {
                                            doc: e.contentDocument,
                                            win: e.contentWindow
                                        }), n = !0)
                                    } catch (t) {}
                                }
                                return n
                            }(w = t) && (function(t) {
                                !1 === ur(t) && mo(t, "load", Xi.bind(this, t, "childList"), !0)
                            }(w), k.attributes["*O"] = "true", w.contentDocument && w.contentWindow && "loading" !== w.contentDocument.readyState && (O = w.contentDocument)), 2 === e && Vi(w), i(t, r, k, e);
                        break;
                    case "LINK":
                        if (tn && "stylesheet" === f.rel) {
                            for (S in Object.keys(document.styleSheets))
                                if ((E = document.styleSheets[S]).ownerNode == s) {
                                    i(t, r, {
                                        tag: "STYLE",
                                        attributes: f,
                                        value: Bi(E)
                                    }, e);
                                    break
                                }
                            break
                        }
                        i(t, r, {
                            tag: d,
                            attributes: f
                        }, e);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in f && f.src.startsWith("data:") && (f.src = ""), i(t, r, {
                            tag: d,
                            attributes: f
                        }, e);
                        break;
                    default:
                        ! function(t) {
                            var e;
                            (null === (e = window.customElements) || void 0 === e ? void 0 : e.get) && window.customElements.get(t) && Ti(t)
                        }(s.localName), T = {
                            tag: d,
                            attributes: f
                        }, s.shadowRoot && (O = s.shadowRoot), i(t, r, T, e)
                }
        }
        return O
    }

    function Fi(t) {
        ur(t) || wo(t) || (function(t) {
            var e, n;
            try {
                (n = (e = Pn("MutationObserver")) in window ? new window[e](vo(Ai)) : null) && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), Yt.set(t, n), xt.add(n)), t.defaultView && Wi(t.defaultView)
            } catch (t) {
                Pr(2, 0, t ? t.name : null)
            }
        }(t), function(t) {
            ! function(t) {
                var e = er(t);
                mo(e ? e.contentWindow : t === document ? window : t, "scroll", it, !0)
            }(t), t.nodeType === Node.DOCUMENT_NODE && (function(t) {
                mo(t, "click", _a.bind(this, 9, t), !0), mo(t, "contextmenu", _a.bind(this, 48, t), !0)
            }(t), function(t) {
                mo(t, "cut", Aa.bind(this, 0), !0), mo(t, "copy", Aa.bind(this, 1), !0), mo(t, "paste", Aa.bind(this, 2), !0)
            }(t), Xa(t), function(t) {
                mo(t, "input", Ra, !0), mo(t, "keydown", La, !0)
            }(t), function(t) {
                mo(t, "selectstart", ei.bind(this, t), !0), mo(t, "selectionchange", ei.bind(this, t), !0)
            }(t), function(t) {
                mo(t, "change", Ta, !0)
            }(t), function(t) {
                mo(t, "submit", ii, !0)
            }(t))
        }(t))
    }

    function Vi(t) {
        bo(t);
        var e, n, a, i = (a = t, (ue.has(a) ? ue.get(a) : null) || {}),
            r = i.doc,
            o = void 0 === r ? null : r,
            u = i.win,
            c = void 0 === u ? null : u;
        c && bo(c), o && (bo(o), e = o, (n = Yt.get(e)) && (n.disconnect(), xt.delete(n), Yt.delete(e)), function(t, e) {
            ue.delete(t), oe.delete(e)
        }(t, o))
    }

    function Bi(t) {
        var e, n = "",
            a = null;
        try {
            a = t ? t.cssRules : []
        } catch (t) {
            if (Pr(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== a)
            for (e = 0; e < a.length; e++) n += a[e].cssText;
        return n
    }

    function Ji(t, e) {
        var n, a, i, r, o = t.attributes,
            u = t.prefix ? t.prefix[e] : null,
            c = 0 === e ? "~" + (t.position - 1) : ":nth-of-type(" + t.position + ")";
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                return null === u ? "" : (u += ">", t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag, n = u + t.tag + c, a = "id" in o && o.id.length > 0 ? o.id : null, i = "BODY" !== t.tag && "class" in o && o.class.length > 0 ? o.class.trim().split(/\s+/).filter((function(t) {
                    return Ki(t)
                })).join(".") : null, i && i.length > 0 && (0 === e ? (r = function(t) {
                    var e, n, a, i;
                    for (e = t.split(">"), n = 0; n < e.length; n++) a = e[n].indexOf("~"), i = e[n].indexOf("."), e[n] = e[n].substring(0, i > 0 ? i : a > 0 ? a : e[n].length);
                    return e.join(">")
                }(u) + t.tag + "." + i, r in Bt || (Bt[r] = []), Bt[r].includes(t.id) || Bt[r].push(t.id), n = r + "~" + Bt[r].indexOf(t.id)) : n = u + t.tag + "." + i + c), n = a && Ki(a) ? function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("iframe:HTML"),
                        a = Math.max(e, n);
                    return a < 0 ? "" : t.substring(0, t.indexOf(">", a) + 1)
                }(u) + "#" + a : n, n)
        }
    }

    function Ki(t) {
        var e, n;
        if (!t) return !1;
        if (Vt.some((function(e) {
                return t.toLowerCase().includes(e)
            }))) return !1;
        for (e = 0; e < t.length; e++)
            if ((n = t.charCodeAt(e)) >= 48 && n <= 57) return !1;
        return !0
    }

    function Gi() {
        Jt = 1, Gt = [], Zt = [], Qt = {}, $t = [], te = [], ee = A, ne = R, ae = P, ie = L, Kt = new Map, re = new WeakMap, oe = new WeakMap, ue = new WeakMap, ce = new WeakMap, le = new WeakMap, Bt = {}
    }

    function Zi(t, e) {
        void 0 === e && (e = !1);
        try {
            e && An.unmask.forEach((function(t) {
                return t.includes("!") ? $t.push(t.substr(1)) : te.push(t)
            })), "querySelectorAll" in t && (An.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return dr(t, "" + e[0])
                }))
            })), An.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return ce.set(t, 3)
                }))
            })), An.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return le.set(t, e[0])
                }))
            })), te.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return ce.set(t, 0)
                }))
            })))
        } catch (t) {
            Pr(5, 1, t ? t.name : null)
        }
    }

    function Qi(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = re.get(t);
        return !n && e && (n = Jt++, re.set(t, n)), n || null
    }

    function $i(t, e, n, a) {
        var i, r, o, u, c, l, s = e ? Qi(e) : null;
        (e && s || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) && (i = Qi(t, !0), r = lr(t), o = null, u = fr(t) ? i : null, c = le.has(t) ? le.get(t) : null, l = An.content ? 1 : 3, s >= 0 && Gt[s] && ((o = Gt[s]).children.push(i), u = null === u ? o.region : u, c = null === c ? o.metadata.fraud : c, l = o.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (dr(t, n.attributes["data-clarity-region"]), u = i), Kt.set(i, t), Gt[i] = {
            id: i,
            parent: s,
            previous: r,
            children: [],
            data: n,
            selector: null,
            hash: null,
            region: u,
            metadata: {
                active: !0,
                suspend: !1,
                privacy: l,
                position: null,
                fraud: c,
                size: null
            }
        }, function(t, e, n) {
            var a, i, r, o, u, c, l, s, d = e.data,
                f = e.metadata,
                h = f.privacy,
                p = d.attributes || {},
                g = d.tag.toUpperCase();
            switch (!0) {
                case ie.includes(g):
                    i = p.type, r = "", o = ["class", "style"], Object.keys(p).filter((function(t) {
                        return !o.includes(t)
                    })).forEach((function(t) {
                        return r += p[t].toLowerCase()
                    })), u = ne.some((function(t) {
                        return r.includes(t)
                    })), f.privacy = "INPUT" === g && ae.includes(i) ? h : u ? 4 : 2;
                    break;
                case "data-clarity-mask" in p:
                    f.privacy = 3;
                    break;
                case "data-clarity-unmask" in p:
                    f.privacy = 0;
                    break;
                case ce.has(t):
                    f.privacy = ce.get(t);
                    break;
                case le.has(t):
                    f.privacy = 2;
                    break;
                case "*T" === g:
                    c = n && n.data ? n.data.tag : "", l = n && n.selector ? n.selector[1] : "", s = ["STYLE", "TITLE", "svg:style"], f.privacy = s.includes(c) || $t.some((function(t) {
                        return l.includes(t)
                    })) ? 0 : h;
                    break;
                case 1 === h:
                    f.privacy = function(t, e, n) {
                        return t && e.some((function(e) {
                            return t.includes(e)
                        })) ? 2 : n.privacy
                    }(p.class, ee, f);
                    break;
                case "IMG" === g:
                    (null === (a = p.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (f.privacy = 3)
            }
        }(t, Gt[i], o), ar(Gt[i]), function(t) {
            if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                var e = rr(t.id);
                !e || e.complete && 0 !== e.naturalWidth || mo(e, "load", (function() {
                    e.setAttribute("data-clarity-loaded", "" + so())
                })), t.metadata.size = []
            }
        }(Gt[i]), sr(i, a))
    }

    function tr(t, e, n, a) {
        var i, r, o, u, c, l = Qi(t),
            s = e ? Qi(e) : null,
            d = lr(t),
            f = !1,
            h = !1;
        if (l in Gt) {
            for (c in (i = Gt[l]).metadata.active = !0, i.previous !== d && (f = !0, i.previous = d), i.parent !== s && (f = !0, r = i.parent, i.parent = s, null !== s && s >= 0 ? (o = null === d ? 0 : Gt[s].children.indexOf(d) + 1, Gt[s].children.splice(o, 0, l), i.region = fr(t) ? l : Gt[s].region) : function(t, e) {
                    if (t in Gt) {
                        var n = Gt[t];
                        n.metadata.active = !1, n.parent = null, sr(t, e), cr(t)
                    }
                }(l, a), null !== r && r >= 0 && (u = Gt[r].children.indexOf(l)) >= 0 && Gt[r].children.splice(u, 1), h = !0), n) nr(i.data, n, c) && (f = !0, i.data[c] = n[c]);
            ar(i), sr(l, a, f, h)
        }
    }

    function er(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && oe.has(e) ? oe.get(e) : null
    }

    function nr(t, e, n) {
        var a;
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function ar(t) {
        var e = t.parent && t.parent in Gt ? Gt[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            i = function(t, e) {
                var n, a;
                for (e.metadata.position = 1, n = t ? t.children.indexOf(e.id) : -1; n-- > 0;)
                    if (a = Gt[t.children[n]], e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                return e.metadata.position
            }(e, t),
            r = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: i,
                attributes: a.attributes
            };
        t.selector = [Ji(r, 0), Ji(r, 1)], t.hash = t.selector.map((function(t) {
            return t ? Yn(t) : null
        })), t.hash.forEach((function(e) {
            return Qt[e] = t.id
        }))
    }

    function ir(t) {
        var e = function(t) {
                return t in Qt ? Qt[t] : null
            }(t),
            n = rr(e);
        return null !== n && null !== n.textContent ? n.textContent.substr(0, 25) : ""
    }

    function rr(t) {
        return Kt.has(t) ? Kt.get(t) : null
    }

    function or(t) {
        var e = Qi(t);
        return e in Gt ? Gt[e] : null
    }

    function ur(t) {
        return Kt.has(Qi(t))
    }

    function cr(t) {
        var e, n, a, i = Kt.get(t);
        if ((null == i ? void 0 : i.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE && (i && (null == i ? void 0 : i.nodeType) === Node.ELEMENT_NODE && "IFRAME" === i.tagName && Vi(i), Kt.delete(t), (e = t in Gt ? Gt[t] : null) && e.children))
            for (n = 0, a = e.children; n < a.length; n++) cr(a[n])
    }

    function lr(t) {
        for (var e = null; null === e && t.previousSibling;) e = Qi(t.previousSibling), t = t.previousSibling;
        return e
    }

    function sr(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !An.lean || !An.lite) {
            var i = Zt.indexOf(t);
            i >= 0 && 1 === e && a ? (Zt.splice(i, 1), Zt.push(t)) : -1 === i && n && Zt.push(t)
        }
    }

    function dr(t, e) {
        !1 === de.has(t) && (de.set(t, e), (ge = null === ge && pe ? new IntersectionObserver(pr, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : ge) && t && t.nodeType === Node.ELEMENT_NODE && ge.observe(t))
    }

    function fr(t) {
        return de && de.has(t)
    }

    function hr() {
        var t, e, n, a, i = [];
        for (t = 0, e = he; t < e.length; t++)(a = Qi((n = e[t]).node)) ? (n.state.data.id = a, fe[a] = n.state.data, se.push(n.state)) : i.push(n);
        he = i, se.length > 0 && Mi(7)
    }

    function pr(t) {
        var e, n, a, i, r, o, u, c, l, s, d;
        for (e = 0, n = t; e < n.length; e++) i = (a = n[e]).target, r = a.boundingClientRect, o = a.intersectionRect, u = a.rootBounds, de.has(i) && r.width + r.height > 0 && u && u.width > 0 && u.height > 0 && (l = (c = i ? Qi(i) : null) in fe ? fe[c] : {
            id: c,
            name: de.get(i),
            interaction: 16,
            visibility: 0
        }, d = ((s = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8) || 10 == l.visibility) && Math.abs(r.top) + u.height > r.height, gr(i, l, l.interaction, d ? 13 : s ? 10 : 0), l.visibility >= 13 && ge && ge.unobserve(i));
        se.length > 0 && Mi(7)
    }

    function gr(t, e, n, a) {
        var i = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in fe && i || !(e.id in fe)) && (fe[e.id] = e, se.push(vr(e))) : he.push({
            node: t,
            state: vr(e)
        })
    }

    function vr(t) {
        return {
            time: Ln(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function mr() {
        se = []
    }

    function yr(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return Rt = Ln() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function br(t, e, n) {
        var a, i, r;
        return void 0 === n && (n = null), a = {
            id: 0,
            hash: null,
            privacy: 2,
            region: ""
        }, t && null !== (i = or(t)) && (r = i.metadata, a.id = i.id, a.hash = i.hash, a.privacy = r.privacy, a.region = i.region ? function(t) {
            var e = rr(t);
            return (e && de ? de.get(e) : "") || ""
        }(i.region) : "", i.region && function(t, e) {
            var n = rr(t),
                a = t in fe ? fe[t] : {
                    id: t,
                    visibility: 0,
                    interaction: 16,
                    name: de.get(n)
                },
                i = 16;
            switch (e) {
                case 9:
                    i = 20;
                    break;
                case 27:
                    i = 30
            }
            gr(n, a, i, a.visibility)
        }(i.region, e), r.fraud && Ea(r.fraud, i.id, n || i.data.value)), a
    }

    function wr(t, e) {
        return void 0 === e && (e = null), aa(this, void 0, void 0, (function() {
            var n, a, i, r, o, u, c, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O, x, I, D, C, A, P, R, L, Y, X, W;
            return ia(this, (function(U) {
                switch (n = e || Ln(), a = [n, t], t) {
                    case 53:
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (i = 0, r = F; i < r.length; i++) Y = r[i], (o = br(Y.data.target, Y.event)).id > 0 && ((a = [Y.time, Y.event]).push(o.id), a.push(Y.data.x), a.push(Y.data.y), a.push(void 0 !== Y.data.id ? Y.data.id : ""), a.push(void 0 === Y.data.isPrimary ? "true" : "" + Y.data.isPrimary), 53 === Y.event && (a.push(Y.data.type), a.push(Y.data.pressure), a.push(Y.data.width), a.push(Y.data.height)), _r(a), 53 === Y.event || void 0 !== Y.data.isPrimary && !Y.data.isPrimary || Vn(Y.event, Y.data.x, Y.data.y, Y.time));
                        Va();
                        break;
                    case 9:
                    case 48:
                        for (u = 0, c = H; u < c.length; u++) Y = c[u], d = br(Y.data.target, Y.event, Y.data.text), a = [Y.time, Y.event], f = d.hash ? d.hash.join(".") : "", a.push(d.id, Y.data.x, Y.data.y, Y.data.eX, Y.data.eY, Y.data.button, Y.data.reaction, Y.data.context, jn(Y.data.text, "click", d.privacy), Xn(Y.data.link), f, Y.data.trust, Y.data.isFullText, Y.data.w, Y.data.h, Y.data.tag, Y.data.class, Y.data.id, Y.data.source), _r(a), Sr(Y.time, Y.event, f, Y.data.x, Y.data.y, Y.data.reaction, Y.data.context);
                        Ca();
                        break;
                    case 38:
                        for (h = 0, p = q; h < p.length; h++) Y = p[h], a = [Y.time, Y.event], (P = br(Y.data.target, Y.event)).id > 0 && (a.push(P.id), a.push(Y.data.action), _r(a));
                        Pa();
                        break;
                    case 11:
                        g = G, a.push(g.width, g.height), Vn(t, g.width, g.height), Ga(), _r(a);
                        break;
                    case 26:
                        v = lt, a.push(v.name, v.persisted), ui(), _r(a);
                        break;
                    case 27:
                        for (m = 0, y = z; m < y.length; m++) Y = y[m], b = br(Y.data.target, Y.event, Y.data.value), (a = [Y.time, Y.event]).push(b.id), a.push(jn(Y.data.value, "input", b.privacy, !1, Y.data.type)), a.push(Y.data.trust), _r(a);
                        ja();
                        break;
                    case 21:
                        (w = rt) && (k = br(w.start, t), S = br(w.end, t), a.push(k.id, w.startOffset, S.id, w.endOffset), ai(), _r(a));
                        break;
                    case 10:
                        for (E = 0, T = tt; E < T.length; E++) Y = T[E], N = br(Y.data.target, Y.event), M = br(Y.data.top, Y.event), _ = br(Y.data.bottom, Y.event), O = (null == M ? void 0 : M.hash) ? M.hash.join(".") : "", x = (null == _ ? void 0 : _.hash) ? _.hash.join(".") : "", N.id > 0 && ((a = [Y.time, Y.event]).push(N.id, Y.data.x, Y.data.y, O, x, Y.data.trust), _r(a), Vn(Y.event, Y.data.x, Y.data.y, Y.time));
                        tt = [], et = null, nt = null;
                        break;
                    case 42:
                        for (I = 0, D = j; I < D.length; I++) Y = D[I], a = [Y.time, Y.event], (P = br(Y.data.target, Y.event)).id > 0 && ((a = [Y.time, Y.event]).push(P.id), a.push(Y.data.type), a.push(jn(Y.data.value, "change", P.privacy)), a.push(jn(Y.data.checksum, "checksum", P.privacy)), _r(a));
                        Na();
                        break;
                    case 39:
                        for (C = 0, A = ct; C < A.length; C++) Y = A[C], a = [Y.time, Y.event], (P = br(Y.data.target, Y.event)).id > 0 && (a.push(P.id), _r(a));
                        ri();
                        break;
                    case 22:
                        for (R = 0, L = me; R < L.length; R++) Y = L[R], (a = [Y.time, Y.event]).push(Y.data.type, Y.data.hash, Y.data.x, Y.data.y, Y.data.reaction, Y.data.context), _r(a, !1);
                        kr();
                        break;
                    case 28:
                        X = st, a.push(X.visible), _r(a),
                            function(t, e) {
                                l.visible = e, l.visible || Jn(t), s = !0
                            }(n, X.visible), li();
                        break;
                    case 50:
                        W = dt, a.push(W.focused), _r(a, !1), si()
                }
                return [2]
            }))
        }))
    }

    function kr() {
        me = []
    }

    function Sr(t, e, n, a, i, r, o) {
        void 0 === r && (r = 1), void 0 === o && (o = 0), ve.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: i,
                reaction: r,
                context: o
            }
        }), Vn(e, a, i, t)
    }

    function Er(t, e, n, a) {
        return "href" === t && "LINK" === a ? t + "=" + e : t + "=" + jn(e, 0 === t.indexOf("data-") ? "data-" : t, n)
    }

    function Tr(t) {
        var e, n = {},
            a = t.attributes;
        if (a && a.length > 0)
            for (e = 0; e < a.length; e++) n[a[e].name] = a[e].value;
        return n
    }

    function Nr(t, e, n) {
        var a, i, r, o;
        t && n && n.tag && (a = function(t) {
            return null === t ? null : we.has(t) ? we.get(t) : (we.set(t, be), be++)
        }(t), i = e ? we.get(e) : null, r = t.previousSibling ? we.get(t.previousSibling) : null, o = {
            active: !0,
            suspend: !1,
            privacy: 5,
            position: null,
            fraud: null,
            size: null
        }, ye.push({
            id: a,
            parent: i,
            previous: r,
            children: [],
            data: n,
            selector: null,
            hash: null,
            region: null,
            metadata: o
        }))
    }

    function Mr(t) {
        var e, n;
        Se && ((n = (e = t ? t.split(" ") : [""]).length > 1 ? parseInt(e[1], 10) : null) && Ee.has(n) || function(t, e) {
            try {
                var n = document.createElement("script");
                n.src = t, n.async = !0, n.onload = function() {
                    e && (Ee.add(e), function(t) {
                        l.modules = Array.from(t), s = !0
                    }(Ee))
                }, n.onerror = function() {
                    go(new Error("MODULE: " + t))
                }, document.head.appendChild(n)
            } catch (t) {}
        }(e[0], n))
    }

    function _r(t, e) {
        var n, a, i, r;
        if (void 0 === e && (e = !0), Ie) {
            switch (n = Ln(), a = t.length > 1 ? t[1] : null, i = JSON.stringify(t), An.lean ? !Ce && Ne + i.length > 10485760 && (Pr(10, 0), Ce = !0) : Ce = !1, a) {
                case 5:
                    if (Ce) break;
                    Te += i.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                case 44:
                case 51:
                    if (Ce) break;
                    Ne += i.length, Me.push(i);
                    break;
                default:
                    _e.push(i)
            }
            Zn(25), r = function() {
                var t = !1 === An.lean && Te > 0 ? 100 : rn.sequence * An.delay;
                return "string" == typeof An.upload ? Math.max(Math.min(t, 3e4), 100) : An.delay
            }(), n - De > 2 * r && (ea(Oe), Oe = null), e && null === Oe && (25 !== a && (m && ea(m), m = ta(na, v), g = Ln()), Oe = ta(Or, r), De = n, function(t) {
                if (0 === Ve.check) {
                    var e = Ve.check;
                    e = rn.sequence >= 128 ? 1 : e, e = rn.pageNum >= 128 ? 7 : e, e = Ln() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Ve.check && Jr(e)
                }
            }(Ne))
        }
    }

    function Or(t) {
        return void 0 === t && (t = !1), aa(this, void 0, void 0, (function() {
            var e, n, a, i, r, o, u, c, l, d;
            return ia(this, (function(f) {
                switch (f.label) {
                    case 0:
                        return Ie ? (Oe = null, (e = !1 === An.lean && Ne > 0 && (Ne < 1048576 || rn.sequence > 0)) && $n(1, 1), hr(), function() {
                            var t, e, n, a, i, r;
                            if (rn) {
                                for (t = [], me = [], e = (rn.start || 0) + (rn.duration || 0), n = Math.max(e - 2e3, 0), a = 0, i = ve; a < i.length; a++)(r = i[a]).time >= n && (r.time <= e && me.push(r), t.push(r));
                                ve = t, wr(22)
                            }
                        }(), function() {
                            var t, e;
                            Br(34), s && Br(4), Br(1), Br(0), Br(36), 0 !== Ve.check && Br(35),
                                function() {
                                    var t, e, n, a, i, r, o, u, c, l, s, d, f, h, p, g, v;
                                    try {
                                        for (t in E)
                                            if (e = parseInt(t), "" == M[e] || document.querySelector(M[e])) {
                                                for (a in n = E[e])(r = (v = va(fa(n[i = parseInt(a)]))) ? JSON.stringify(v).slice(0, 1e4) : v) && pa(e, i, r);
                                                for (u in o = T[e]) c = !1, (s = o[l = parseInt(u)]).startsWith("@") && (c = !0, s = s.slice(1)), (d = document.querySelectorAll(s)) && (f = Array.from(d).map((function(t) {
                                                    if ("IMG" === t.tagName) {
                                                        var e = t;
                                                        return e.src || e.currentSrc || ""
                                                    }
                                                    return t.textContent
                                                })).join("<SEP>"), pa(e, l, (c ? Yn(f).trim() : f).slice(0, 1e4)));
                                                for (p in h = N[e]) pa(e, g = parseInt(p), ir(h[g]).trim().slice(0, 1e4))
                                            }
                                        S.size > 0 && Br(40)
                                    } catch (t) {
                                        Pr(5, 1, t ? t.name : null)
                                    }
                                }(), Ze && (Br(47), Ze = !1, An.track || (null == (e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics) ? void 0 : e.usedUpdate) && Gr())
                        }(), function() {
                            var t, e, n, a;
                            for (t = 0, e = yt; t < e.length; t++) mi(n = e[t], (a = n == document ? -1 : Qi(n)) in mt ? mt[a] : null)
                        }(), n = !0 === t, rn ? (a = JSON.stringify(function(t) {
                            return rn.start = rn.start + rn.duration, rn.duration = Ln() - rn.start, rn.sequence++, rn.upload = t && "sendBeacon" in navigator ? 1 : 0, rn.end = t ? 1 : 0, rn.applicationPlatform = 0, rn.url = Xn(location.href, !1, !0), [rn.version, rn.sequence, rn.start, rn.duration, rn.projectId, rn.userId, rn.sessionId, rn.pageNum, rn.upload, rn.end, rn.applicationPlatform, rn.url]
                        }(n)), i = _e, _e = [], e && (r = Me, Me = [], Ne = 0, Te = 0, Ce = !1), o = "[" + i.join() + "]", u = e ? "[" + r.join() + "]" : "", n && u.length > 0 && a.length + o.length + u.length > 65536 && (u = ""), c = (h = {
                            e: a,
                            a: o,
                            p: u
                        }).p.length > 0 ? '{"e":' + h.e + ',"a":' + h.a + ',"p":' + h.p + "}" : '{"e":' + h.e + ',"a":' + h.a + "}", n ? (d = null, [3, 3]) : [3, 1]) : [2]) : [2];
                    case 1:
                        return [4, ra(c)];
                    case 2:
                        d = f.sent(), f.label = 3;
                    case 3:
                        return Qn(2, (l = d) ? l.length : c.length), xr(c, l, rn.sequence, n), [2]
                }
                var h
            }))
        }))
    }

    function xr(t, e, n, a) {
        var i, r, o;
        if (void 0 === a && (a = !1), "string" == typeof An.upload) {
            if (i = An.upload, r = !1, a && navigator && navigator.sendBeacon) try {
                (r = navigator.sendBeacon.bind(navigator)(i, t)) && Dr(n)
            } catch (t) {}!1 === r && (n in xe ? xe[n].attempts++ : xe[n] = {
                data: t,
                attempts: 1
            }, (o = new XMLHttpRequest).open("POST", i, !0), o.timeout = 15e3, o.ontimeout = function() {
                go(new Error("Timeout : " + i))
            }, null !== n && (o.onreadystatechange = function() {
                vo(Ir)(o, n)
            }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t))
        } else An.upload && ((0, An.upload)(t), Dr(n))
    }

    function Ir(t, e) {
        var n = xe[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? Jr(6) : (0 === t.status && (An.upload = An.fallback ? An.fallback : An.upload), Ae = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, Br(2), xr(n.data, null, e)) : (Ae = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Br(2), 200 === t.status && t.responseText && function(t) {
            var e, n, a, i;
            for (e = 0, n = t && t.length > 0 ? t.split("\n") : []; e < n.length; e++) switch ((i = (a = n[e]) && a.length > 0 ? a.split(/ (.*)/) : [""])[0]) {
                case "END":
                    Jr(6);
                    break;
                case "UPGRADE":
                    Vr("Auto");
                    break;
                case "ACTION":
                    An.action && i.length > 1 && An.action(i[1]);
                    break;
                case "EXTRACT":
                    i.length > 1 && da(i[1]);
                    break;
                case "SIGNAL":
                    i.length > 1 && Sa(i[1]);
                    break;
                case "MODULE":
                    i.length > 1 && Mr(i[1]);
                    break;
                case "SNAPSHOT":
                    An.lean = !1, ye = [],
                        function(t) {
                            for (var e, n, a, i, r, o, u, c, l = [document]; l.length > 0;) {
                                for (e = null, n = null, a = null, r = (i = l.shift()).firstChild, o = i.parentElement ? i.parentElement : i.parentNode ? i.parentNode : null; r;) l.push(r), r = r.nextSibling;
                                switch (i.nodeType) {
                                    case Node.DOCUMENT_TYPE_NODE:
                                        n = "*D", e = {
                                            name: (u = i).name,
                                            publicId: u.publicId,
                                            systemId: u.systemId
                                        };
                                        break;
                                    case Node.TEXT_NODE:
                                        a = i.nodeValue, n = we.get(o) ? "*T" : n;
                                        break;
                                    case Node.ELEMENT_NODE:
                                        e = Tr(c = i), n = ["NOSCRIPT", "SCRIPT", "STYLE"].includes(c.tagName) ? n : c.tagName
                                }
                                Nr(i, o, {
                                    tag: n,
                                    attributes: e,
                                    value: a
                                })
                            }
                        }(),
                        function(t) {
                            aa(this, void 0, void 0, (function() {
                                var t, e, n, a, i, r, o, u, c, l, s, d;
                                return ia(this, (function(f) {
                                    if (t = Ln(), e = [t, 43], (n = ye).length > 0) {
                                        for (a = 0, i = n; a < i.length; a++)
                                            for (r = i[a], o = r.metadata.privacy, u = r.data, c = 0, l = ["tag", "attributes", "value"]; c < l.length; c++)
                                                if (u[s = l[c]]) switch (s) {
                                                    case "tag":
                                                        e.push(r.id), r.parent && e.push(r.parent), r.previous && e.push(r.previous), e.push(u[s]);
                                                        break;
                                                    case "attributes":
                                                        for (d in u[s]) void 0 !== u[s][d] && e.push(Er(d, u[s][d], o, u.tag));
                                                        break;
                                                    case "value":
                                                        e.push(jn(u[s], u.tag, o))
                                                }
                                        _r(hi(e), !0)
                                    }
                                    return [2]
                                }))
                            }))
                        }()
            }
        }(t.responseText), 0 === t.status && (xr(n.data, null, e, !0), Jr(3)), t.status >= 200 && t.status <= 208 && Dr(e), delete xe[e]))
    }

    function Dr(t) {
        1 === t && (co(), uo())
    }

    function Cr(t) {
        var e = t.error || t;
        return e.message in Pe || (Pe[e.message] = 0), Pe[e.message]++ >= 5 || e && e.message && (Re = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, Ar(31)), !0
    }

    function Ar(t) {
        return aa(this, void 0, void 0, (function() {
            var e;
            return ia(this, (function(n) {
                switch (e = [Ln(), t], t) {
                    case 31:
                        e.push(Re.message, Re.line, Re.column, Re.stack, Xn(Re.source)), _r(e);
                        break;
                    case 33:
                        Ye && (e.push(Ye.code, Ye.name, Ye.message, Ye.stack, Ye.severity), _r(e, !1));
                        break;
                    case 41:
                        C && (e.push(C.id, C.target, C.checksum), _r(e, !1))
                }
                return [2]
            }))
        }))
    }

    function Pr(t, e, n, a, i) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === i && (i = null);
        var r = n ? n + "|" + a : "";
        t in Le && Le[t].includes(r) || (Ye = {
            code: t,
            name: n,
            message: a,
            stack: i,
            severity: e
        }, t in Le ? Le[t].push(r) : Le[t] = [r], Ar(33))
    }

    function Rr() {
        Xe = {}, We = [], He = null, qe = null
    }

    function Lr(t, e) {
        return void 0 === e && (e = 0), aa(this, void 0, void 0, (function() {
            var n, a, i;
            return ia(this, (function(r) {
                for (n = 0, a = We; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return i = new Promise((function(n) {
                    We[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: eo()
                    })
                })), null === He && null === qe && Yr(), [2, i]
            }))
        }))
    }

    function Yr() {
        var t = We.shift();
        t && (He = t, t.task().then((function() {
            t.id !== eo() || t.resolve(), He = null, Yr()
        })).catch((function(e) {
            !(t.id !== eo()) && e && Pr(0, 1, e.name, e.message, e.stack), He = null, Yr()
        })))
    }

    function jr(t) {
        var e = qr(t);
        return e in Xe ? performance.now() - Xe[e].start > Xe[e].yield ? 0 : 1 : 2
    }

    function Xr(t) {
        Xe[qr(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function Wr(t) {
        var e = performance.now(),
            n = qr(t),
            a = e - Xe[n].start;
        Qn(t.cost, a), Zn(5), Xe[n].calls > 0 && Qn(4, a)
    }

    function Hr(t) {
        var e;
        return aa(this, void 0, void 0, (function() {
            var n, a;
            return ia(this, (function(i) {
                switch (i.label) {
                    case 0:
                        return (n = qr(t)) in Xe ? (Wr(t), a = Xe[n], [4, Ur()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = i.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e, n, a = qr(t);
                                Xe && Xe[a] && (e = Xe[a].calls, n = Xe[a].yield, Xr(t), Xe[a].calls = e + 1, Xe[a].yield = n)
                            }(t), i.label = 2;
                    case 2:
                        return [2, n in Xe ? 1 : 2]
                }
            }))
        }))
    }

    function qr(t) {
        return t.id + "." + t.cost
    }

    function Ur() {
        return aa(this, void 0, void 0, (function() {
            return ia(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return qe ? [4, qe] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            ze(t, {
                                timeout: je
                            })
                        }))]
                }
            }))
        }))
    }

    function zr() {
        Lr(Fr, 1).then((function() {
            vo(Ii)(), vo(hr)(), vo(ti)()
        }))
    }

    function Fr() {
        return aa(this, void 0, void 0, (function() {
            var t, e;
            return ia(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = Ln(), Xr(e = {
                            id: eo(),
                            cost: 3
                        }), [4, Di(document, e, 0, t)];
                    case 1:
                        return n.sent(), mi(document, t), [4, Mi(5, e, t)];
                    case 2:
                        return n.sent(), Wr(e), [2]
                }
            }))
        }))
    }

    function Vr(t) {
        Mo() && An.lean && (An.lean = !1, Fe = {
            key: t
        }, uo(), co(), An.upgrade && An.upgrade(t), Br(3), An.lite && (zr(), vi()))
    }

    function Br(t) {
        var e, n, a, i, r, o, u, l, s, f, g, v, m, b, E, T, N, M, _ = [Ln(), t];
        switch (t) {
            case 4:
                (e = c) && e.data && (n = e.data, (_ = [e.time, e.event]).push(n.visible, n.docWidth, n.docHeight, n.screenWidth, n.screenHeight, n.scrollX, n.scrollY, n.pointerX, n.pointerY, n.activityTime, n.scrollTime, n.pointerTime, n.moveX, n.moveY, n.moveTime, n.downX, n.downY, n.downTime, n.upX, n.upY, n.upTime, n.pointerPrevX, n.pointerPrevY, n.pointerPrevTime, n.modules), _r(_, !1)), Fn();
                break;
            case 25:
                _.push(p.gap), _r(_);
                break;
            case 35:
                _.push(Ve.check), _r(_, !1);
                break;
            case 3:
                _.push(Fe.key), _r(_);
                break;
            case 2:
                _.push(Ae.sequence, Ae.attempts, Ae.status), _r(_, !1);
                break;
            case 24:
                d.key && _.push(d.key), _.push(d.value), _r(_);
                break;
            case 34:
                if ((a = Object.keys(w)).length > 0) {
                    for (i = 0, r = a; i < r.length; i++) o = r[i], _.push(o), _.push(w[o]);
                    ca(), _r(_, !1)
                }
                break;
            case 0:
                if ((u = Object.keys(h)).length > 0) {
                    for (l = 0, s = u; l < s.length; l++) f = s[l], g = parseInt(f, 10), _.push(g), _.push(Math.round(h[f]));
                    h = {}, _r(_, !1)
                }
                break;
            case 1:
                if ((v = Object.keys(Je)).length > 0) {
                    for (m = 0, b = v; m < b.length; m++) n = b[m], g = parseInt(n, 10), _.push(g), _.push(Je[n]);
                    Je = {}, Ke = !1, _r(_, !1)
                }
                break;
            case 36:
                if ((E = Object.keys(y)).length > 0) {
                    for (T = 0, N = E; T < N.length; T++) M = N[T], g = parseInt(M, 10), _.push(g), _.push([].concat.apply([], y[M]));
                    y = {}, _r(_, !1)
                }
                break;
            case 40:
                S.forEach((function(t) {
                    var e, n, a;
                    for (n in _.push(t), e = [], k[t]) a = parseInt(n, 10), e.push(a), e.push(k[t][n]);
                    _.push(e)
                })), ha(), _r(_, !1);
                break;
            case 47:
                _.push(Ge.source, Ge.ad_Storage, Ge.analytics_Storage), _r(_, !1)
        }
    }

    function Jr(t) {
        Ve.check = t, 5 !== t && (ro(), Po())
    }

    function Kr(t, e) {
        if (e && (e = "" + e, t in Be || (Be[t] = []), !Be[t].includes(e))) {
            if (Be[t].length > 128) return void(Ke || (Ke = !0, Jr(5)));
            Be[t].push(e), t in Je || (Je[t] = []), Je[t].push(e)
        }
    }

    function Gr() {
        var t, e, n, a = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        if (null == a ? void 0 : a.getConsentState) try {
            e = a.getConsentState("analytics_storage"), no({
                source: 2,
                ad_Storage: 1 === (n = {
                    ad_Storage: a.getConsentState("ad_storage"),
                    analytics_Storage: e
                }).ad_Storage ? "granted" : "denied",
                analytics_Storage: 1 === n.analytics_Storage ? "granted" : "denied"
            })
        } catch (t) {
            return
        }
    }

    function Zr() {
        Qr(2)
    }

    function Qr(t) {
        Kr(36, "" + t)
    }

    function $r(t) {
        Ge = t, Br(47)
    }

    function to() {
        var t, e, n, a;
        if (!nn && "granted" === (null == en ? void 0 : en.analytics_Storage) && "granted" === (null == en ? void 0 : en.ad_Storage)) {
            for (t = 0, e = An.cookies; t < e.length; t++)(a = wa(n = e[t])) && oa(n, a);
            nn = !0
        }
    }

    function eo() {
        return Qe ? [Qe.userId, Qe.sessionId, Qe.pageNum].join(".") : ""
    }

    function no(t, e) {
        var n, a, i;
        if (void 0 === t && (t = an), void 0 === e && (e = 5), Mo()) {
            if (a = {
                    source: null !== (n = t.source) && void 0 !== n ? n : e,
                    ad_Storage: io(t.ad_Storage, null == en ? void 0 : en.ad_Storage),
                    analytics_Storage: io(t.analytics_Storage, null == en ? void 0 : en.analytics_Storage)
                }, en && a.ad_Storage === en.ad_Storage && a.analytics_Storage === en.analytics_Storage) return en.source = a.source, $r(ao(en)), void Zr();
            if (en = a, uo(!0), !(i = ao(en)).analytics_Storage && An.track) return An.track = !1, ro(!0), Po(), void window.setTimeout(Ao, 250);
            Mo() && i.analytics_Storage && (An.track = !0, lo(ho(), 1), Kr(15, oo()), co()), to(), $r(i), Zr()
        }
    }

    function ao(t) {
        var e;
        return {
            source: null !== (e = t.source) && void 0 !== e ? e : 255,
            ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
            analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0
        }
    }

    function io(t, e) {
        return void 0 === e && (e = "denied"), "string" == typeof t ? t.toLowerCase() : e
    }

    function ro(t) {
        void 0 === t && (t = !1), ka("_clsk", "", 0), t && ka("_clck", "", 0)
    }

    function oo() {
        var t = so();
        return An.track && ya(window, "sessionStorage") && (t = sessionStorage.getItem("_cltk") || t, sessionStorage.setItem("_cltk", t)), t
    }

    function uo(t) {
        void 0 === t && (t = !1),
            function(t, e) {
                var n, a;
                if (void 0 === e && (e = !1), $e.length > 0)
                    for (n = 0; n < $e.length; n++)(a = $e[n]).callback && (!a.called && !e || a.consentInfo && e) && (!a.wait || t) && (a.callback(Qe, !An.lean, a.consentInfo ? en : void 0), a.called = !0, a.recall || ($e.splice(n, 1), n--))
            }(An.lean ? 0 : 1, t)
    }

    function co() {
        var t, e, n;
        Qe && An.track && (t = Math.round(Date.now()), e = An.upload && "string" == typeof An.upload ? An.upload.replace("https://", "") : "", n = An.lean ? 0 : 1, ka("_clsk", [Qe.sessionId, t, Qe.pageNum, n, e].join(O), 1))
    }

    function lo(t, e) {
        var n, a;
        void 0 === e && (e = null), e = null === e ? t.consent : e, n = Math.ceil((Date.now() + 31536e6) / 864e5), a = 0 === t.dob ? null === An.dob ? 0 : An.dob : t.dob, (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && ka("_clck", [Qe.userId, 2, n.toString(36), e, a].join(O), 365)
    }

    function so() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function fo(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function ho() {
        var t, e = {
                id: so(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            n = wa("_clck", !An.includeSubdomains);
        return n && n.length > 0 && ((t = n.includes("^") ? n.split("^") : n.split("|")).length > 1 && (e.version = fo(t[1])), t.length > 2 && (e.expiry = fo(t[2], 36)), t.length > 3 && 1 === fo(t[3]) && (e.consent = 1), t.length > 4 && fo(t[1]) > 1 && (e.dob = fo(t[4])), An.track = An.track || 1 === e.consent, e.id = An.track ? t[0] : e.id), e
    }

    function po() {
        on = []
    }

    function go(t) {
        var e, n, a;
        return on && !on.includes(t.message) && (e = An.report) && e.length > 0 && rn && (n = {
            v: rn.version,
            p: rn.projectId,
            u: rn.userId,
            s: rn.sessionId,
            n: rn.pageNum
        }, t.message && (n.m = t.message), t.stack && (n.e = t.stack), (a = new XMLHttpRequest).open("POST", e, !0), a.send(JSON.stringify(n)), on.push(t.message)), t
    }

    function vo(t) {
        return function() {
            var e, n = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw go(t)
            }
            Qn(4, e = performance.now() - n), e > 30 && (Zn(7), $n(6, e), t.dn && Pr(9, 0, t.dn + "-" + e))
        }
    }

    function mo(t, e, n, a, i) {
        void 0 === a && (a = !1), void 0 === i && (i = !0), n = vo(n);
        try {
            t[Pn("addEventListener")](e, n, {
                capture: a,
                passive: i
            }), wo(t) || un.set(t, []), un.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: i
                }
            })
        } catch (t) {}
    }

    function yo() {
        un.forEach((function(t, e) {
            ko(t, e)
        })), un = new Map
    }

    function bo(t) {
        wo(t) && ko(un.get(t), t)
    }

    function wo(t) {
        return un.has(t)
    }

    function ko(t, e) {
        t.forEach((function(t) {
            try {
                e[Pn("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), un.delete(e)
    }

    function So(t, e) {
        if (null === t) try {
            t = history[e], history[e] = function() {
                if (dn >= 20) Pr(4, 0);
                else {
                    dn++;
                    try {
                        t.apply(this, arguments)
                    } finally {
                        dn--
                    }
                    Mo() && Eo()
                }
            }
        } catch (e) {
            t = null
        }
        return t
    }

    function Eo() {
        var t;
        sn !== No() && (Po(), window.setTimeout(To, null !== (t = An.restart) && void 0 !== t ? t : 250))
    }

    function To() {
        Ao(), $n(29, 1)
    }

    function No() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }

    function Mo() {
        return fn
    }

    function _o() {
        Ao(), Kn("clarity", "restart")
    }

    function Oo() {
        hn = null
    }

    function xo(t) {
        hn = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                aa(this, void 0, void 0, (function() {
                    var t, e;
                    return ia(this, (function(n) {
                        return t = Ln(), (e = [t, 29]).push(hn.fetchStart, hn.connectStart, hn.connectEnd, hn.requestStart, hn.responseStart, hn.responseEnd, hn.domInteractive, hn.domComplete, hn.loadEventStart, hn.loadEventEnd, hn.redirectCount, hn.size, hn.type, hn.protocol, hn.encodedSize, hn.decodedSize), Oo(), _r(e), [2]
                    }))
                }))
            }()
    }

    function Io() {
        var t, e, n;
        try {
            for (Mn && Mn.disconnect(), Mn = new PerformanceObserver(vo(Do)), t = 0, e = _n; t < e.length; t++) n = e[t], PerformanceObserver.supportedEntryTypes.includes(n) && ("layout-shift" === n && Qn(9, 0), Mn.observe({
                type: n,
                buffered: !0
            }))
        } catch (t) {
            Pr(3, 1)
        }
    }

    function Do(t) {
        ! function(t) {
            var e, n, a, i;
            for ((e = !("visibilityState" in document) || "visible" === document.visibilityState, n = 0); n < t.length; n++) switch ((a = t[n]).entryType) {
                case "navigation":
                    xo(a);
                    break;
                case "resource":
                    Kr(4, Co(i = a.name)), i !== An.upload && i !== An.fallback || $n(28, a.duration);
                    break;
                case "longtask":
                    Zn(7);
                    break;
                case "first-input":
                    e && $n(10, a.processingStart - a.startTime);
                    break;
                case "event":
                    e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (Nn(a), Kr(37, "" + En()));
                    break;
                case "layout-shift":
                    e && !a.hadRecentInput && Qn(9, 1e3 * a.value);
                    break;
                case "largest-contentful-paint":
                    e && $n(8, a.startTime)
            }
        }(t.getEntries())
    }

    function Co(t) {
        return On || (On = document.createElement("a")), On.href = t, On.host
    }

    function Ao(e) {
        void 0 === e && (e = null),
            function(t) {
                void 0 === t && (t = null);
                try {
                    var e = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === fn && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && (!e || t && t.diagnostics)
                } catch (t) {
                    return !1
                }
            }(e) && (function(t) {
                if (null === t || fn) return !1;
                for (var e in t) e in An && (An[e] = t[e])
            }(e), fn = !0, t = Rn(), Rr(), yo(), po(), sn = No(), dn = 0, mo(window, "popstate", Eo), cn = So(cn, "pushState"), ln = So(ln, "replaceState"), f = {}, h = {}, Zn(5), I.forEach((function(t) {
                return vo(t.start)()
            })), xn.forEach((function(t) {
                return vo(t.start)()
            })), null === e && Ro())
    }

    function Po() {
        Mo() && (xn.slice().reverse().forEach((function(t) {
            return vo(t.stop)()
        })), I.slice().reverse().forEach((function(t) {
            return vo(t.stop)()
        })), f = {}, h = {}, sn = null, dn = 0, po(), yo(), Rr(), t = 0, fn = !1, void 0 !== Dn && (Dn[Cn] = function() {
            (Dn[Cn].q = Dn[Cn].q || []).push(arguments), "start" === arguments[0] && Dn[Cn].q.unshift(Dn[Cn].q.pop()) && Ro()
        }))
    }

    function Ro() {
        if (void 0 !== Dn) {
            if (Dn[Cn] && Dn[Cn].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = Dn[Cn] && Dn[Cn].q || [];
            for (Dn[Cn] = function(t) {
                    var e, n = [];
                    for (e = 1; e < arguments.length; e++) n[e - 1] = arguments[e];
                    return In[t].apply(In, n)
                }, Dn[Cn].v = e; t.length > 0;) Dn[Cn].apply(Dn, t.shift())
        }
    }
    t = 0, e = "0.8.72-beta", n = /\S/gi, a = 2048, i = !0, r = null, o = null, u = null, c = null, l = null, s = !1, d = null, f = null, h = null, g = 0, v = 0, m = null, y = null, b = "CompressionStream" in window, w = null, k = {}, S = new Set, E = {}, T = {}, N = {}, M = {}, _ = null, O = "^", x = null, I = [{
        start: function() {
            s = !1, Fn()
        },
        stop: function() {
            Fn()
        }
    }, {
        start: function() {
            Be = {}, Je = {}, Ke = !1
        },
        stop: function() {
            Be = {}, Je = {}, Ke = !1
        }
    }, {
        start: function() {
            ca()
        },
        stop: function() {
            ca()
        }
    }, {
        start: function() {
            Ve = {
                check: 0
            }
        },
        stop: function() {
            Ve = null
        }
    }, {
        start: function() {
            y = {}
        },
        stop: function() {
            y = {}
        }
    }, {
        start: function() {
            _ = null
        },
        stop: function() {
            _ = null
        }
    }, {
        start: function() {
            var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
            Ze = !0, (null == e ? void 0 : e.addListener) && e.addListener(["ad_storage", "analytics_storage"], Gr)
        },
        stop: function() {
            Ze = !0
        }
    }, {
        start: function() {
            var t, e, n, a, i, r, o, u, c, l, s, d, f = navigator && "userAgent" in navigator ? navigator.userAgent : "",
                h = null !== (n = "undefined" != typeof Intl && (null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone)) && void 0 !== n ? n : "",
                p = "" + (new Date).getTimezoneOffset(),
                g = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
                v = document && document.title ? document.title : "";
            tn = f.indexOf("Electron") > 0 ? 1 : 0, l = {
                session: so(),
                ts: Math.round(Date.now()),
                count: 1,
                upgrade: null,
                upload: ""
            }, (s = wa("_clsk", !An.includeSubdomains)) && (c = s.includes("^") ? s.split("^") : s.split("|")).length >= 5 && l.ts - fo(c[1]) < 18e5 && (l.session = c[0], l.count = fo(c[2]) + 1, l.upgrade = fo(c[3]), l.upload = c.length >= 6 ? "https://" + c[5] + "/" + c[4] : "/" === c[4][0] ? c[4] : "https://" + c[4]), a = l, i = ho(), r = An.projectId || Yn(location.host), Qe = {
                projectId: r,
                userId: i.id,
                sessionId: a.session,
                pageNum: a.count
            }, An.lean = An.track && null !== a.upgrade ? 0 === a.upgrade : An.lean, An.upload = An.track && "string" == typeof An.upload && a.upload && a.upload.length > "https://".length ? a.upload : An.upload, Kr(0, f), Kr(3, v), Kr(1, Xn(location.href, !!tn)), Kr(2, document.referrer), Kr(15, oo()), Kr(16, document.documentElement.lang), Kr(17, document.dir), Kr(26, "" + window.devicePixelRatio), Kr(28, "" + i.dob), Kr(29, "" + i.version), Kr(33, g), Kr(34, h), Kr(35, p), Kr(38, "" + !(!navigator || !navigator.globalPrivacyControl)), $n(0, a.ts), $n(1, 0), $n(35, tn), (o = null === window || void 0 === window ? void 0 : window.Zone) && "__symbol__" in o && $n(39, 1), navigator && (Kr(9, navigator.language), $n(33, navigator.hardwareConcurrency), $n(32, navigator.maxTouchPoints), $n(34, Math.round(navigator.deviceMemory)), (u = navigator.userAgentData) && u.getHighEntropyValues ? u.getHighEntropyValues(["model", "platformVersion"]).then((function(t) {
                var e;
                Kr(22, t.platform), Kr(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                    Kr(24, t.brand + "~" + t.version)
                })), Kr(25, t.model), $n(27, t.mobile ? 1 : 0)
            })) : Kr(22, navigator.platform)), screen && ($n(14, Math.round(screen.width)), $n(15, Math.round(screen.height)), $n(16, Math.round(screen.colorDepth))), null === en && (en = {
                source: i.consent ? 6 : 0,
                ad_Storage: An.track ? "granted" : "denied",
                analytics_Storage: An.track ? "granted" : "denied"
            }), to(), Qr((d = ao(en)).analytics_Storage ? 1 : 0), Ge = d, lo(i)
        },
        stop: function() {
            Qe = null, nn = !1, $e.forEach((function(t) {
                t.called = !1
            }))
        }
    }, {
        start: function() {
            var t = Qe;
            rn = {
                version: e,
                sequence: 0,
                start: 0,
                duration: 0,
                projectId: t.projectId,
                userId: t.userId,
                sessionId: t.sessionId,
                pageNum: t.pageNum,
                upload: 0,
                end: 0,
                applicationPlatform: 0,
                url: ""
            }
        },
        stop: function() {
            rn = null
        }
    }, {
        start: function() {
            Ie = !0, Te = 0, Ne = 0, Ce = !1, De = 0, Me = [], _e = [], xe = {}, Ae = null
        },
        stop: function() {
            ea(Oe), Or(!0), Te = 0, Ne = 0, Ce = !1, De = 0, Me = [], _e = [], xe = {}, Ae = null, Ie = !1
        }
    }, {
        start: function() {
            v = 6e4, g = 0
        },
        stop: function() {
            ea(m), g = 0, v = 0
        }
    }, {
        start: function() {
            !An.lean && An.upgrade && An.upgrade("Config"), Fe = null
        },
        stop: function() {
            Fe = null
        }
    }, {
        start: function() {
            ha()
        },
        stop: function() {
            ha()
        }
    }], D = [], A = ["address", "password", "contact"], P = ["radio", "checkbox", "range", "button", "reset", "submit"], R = ["password", "secret", "pass", "social", "ssn", "code", "hidden"], L = ["INPUT", "SELECT", "TEXTAREA"], Y = ["load", "active", "fixed", "visible", "focus", "show", "collaps", "animat"], j = [], X = ["input", "textarea", "radio", "button", "canvas", "select"], W = /VM\d/, H = [], q = [], U = null, z = [], F = [], V = null, B = !1, J = 0, K = new Set, Z = null, Q = !1, $ = Ba(Ja, 500), tt = [], et = null, nt = null, at = null, it = Ba(Za, 25), rt = null, ot = null, ut = null, ct = [], ft = !1, ht = [], pt = [], gt = "__clrSId", vt = {}, mt = {}, yt = [], bt = [], wt = [], kt = null, St = !1, Et = "__clrAId", Tt = "__clrOCnt", Nt = 20, Mt = [], _t = new Set, xt = new Set, It = [], Dt = {}, Ct = [], At = null, Pt = null, Rt = null, Lt = {}, Yt = new WeakMap, jt = ["data-google-query-id", "data-load-complete", "data-google-container-id"], Xt = /[^0-9\.]/g, Wt = "claude-agent-glow-border", Ht = "claude-phantom-cursor", qt = "codex-agent-overlay-root", Ut = "codex-browser-sidebar-comments-root", zt = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label", "integrity", "crossorigin"], Ft = /[\r\n]+/g, Vt = Y, Bt = {}, Jt = 1, Kt = null, Gt = [], Zt = [], Qt = {}, $t = [], te = [], ee = [], ne = [], ae = [], ie = [], re = null, oe = null, ue = null, ce = null, le = null, se = [], de = null, fe = {}, he = [], pe = !1, ge = null, ve = [], me = [], ye = [], be = 1, we = null, ke = [], Se = !1, Ee = null, Te = 0, Ne = 0, Oe = null, De = 0, Ce = !1, Pe = {}, Le = {}, je = 5e3, Xe = {}, We = [], He = null, qe = null, Ue = null, ze = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            i = a.port1,
            r = a.port2;
        i.onmessage = function(a) {
            var i, o = performance.now(),
                u = o - n,
                c = o - a.data;
            c > 30 && u < e.timeout ? requestAnimationFrame((function() {
                r.postMessage(o)
            })) : (i = u > e.timeout, t({
                didTimeout: i,
                timeRemaining: function() {
                    return i ? 30 : Math.max(0, 30 - c)
                }
            }))
        }, requestAnimationFrame((function() {
            r.postMessage(performance.now())
        }))
    }, Fe = null, Be = null, Je = null, Ke = !1, Ge = null, Ze = !0, Qe = null, $e = [], tn = 0, en = null, nn = !1, an = {
        source: 7,
        ad_Storage: "denied",
        analytics_Storage: "denied"
    }, rn = null, un = new Map, cn = null, ln = null, sn = null, dn = 0, fn = !1, hn = null, pn = 0, gn = 1 / 0, vn = 0, mn = 0, yn = [], bn = new Map, wn = function(t) {
        "interactionCount" in performance ? pn = performance.interactionCount : t.interactionId && (gn = Math.min(gn, t.interactionId), vn = Math.max(vn, t.interactionId), pn = vn ? (vn - gn) / 7 + 1 : 0)
    }, kn = function() {
        return pn || 0
    }, Sn = function() {
        return kn() - mn
    }, En = function() {
        if (!yn.length) return -1;
        var t = Math.min(yn.length - 1, Math.floor(Sn() / 50));
        return yn[t].latency
    }, Tn = function() {
        mn = kn(), yn.length = 0, bn.clear()
    }, Nn = function(t) {
        var e, n, a;
        !t.interactionId || t.duration < 40 || (wn(t), e = yn[yn.length - 1], ((n = bn.get(t.interactionId)) || yn.length < 10 || t.duration > (null == e ? void 0 : e.latency)) && (n ? t.duration > n.latency && (n.latency = t.duration) : (a = {
            id: t.interactionId,
            latency: t.duration
        }, bn.set(a.id, a), yn.push(a)), yn.sort((function(t, e) {
            return e.latency - t.latency
        })), yn.length > 10 && yn.splice(10).forEach((function(t) {
            return bn.delete(t.id)
        }))))
    }, _n = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"], On = null, xn = [{
        start: function() {
            ! function() {
                D = [], $n(26, navigator.webdriver ? 1 : 0);
                try {
                    $n(31, window.top == window.self || window.top == window ? 1 : 2)
                } catch (t) {
                    $n(31, 0)
                }
            }(), mo(window, "error", Cr), Pe = {}, Le = {}
        },
        stop: function() {
            Le = {}
        }
    }, {
        start: function() {
            xi(), Ii(), mr(), ge = null, de = new WeakMap, fe = {}, he = [], pe = !!window.IntersectionObserver, Gi(), Zi(document, !0), An.delayDom ? mo(window, "load", (function() {
                    Ci()
                })) : Ci(),
                function() {
                    var t;
                    try {
                        window.__clr = window.__clr || {}, (null === (t = window.customElements) || void 0 === t ? void 0 : t.define) && !window.__clr.define && (window.__clr.define = window.customElements.define, window.customElements.define = function() {
                            return Mo() && Ti(arguments[0]), window.__clr.define.apply(this, arguments)
                        })
                    } catch (t) {}
                }(), zr(), vi(),
                function() {
                    var t, e, n;
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (wi(), St || (St = !0, ["play", "pause", "commitStyles", "cancel", "finish"].forEach(Si)), null === kt && (kt = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = kt.apply(this, arguments);
                            return Ei(t, "play"), t
                        }), document.getAnimations))
                        for (t = 0, e = document.getAnimations(); t < e.length; t++) "finished" === (n = e[t]).playState ? Ei(n, "finish") : "paused" === n.playState || "idle" === n.playState ? Ei(n, "pause") : "running" === n.playState && Ei(n, "play")
                }()
        },
        stop: function() {
            mr(), de = null, fe = {}, he = [], ge && (ge.disconnect(), ge = null), pe = !1, Gi(),
                function() {
                    var t, e, n;
                    for (t = 0, e = Array.from(xt); t < e.length; t++)(n = e[t]) && n.disconnect();
                    xt = new Set, Lt = {}, It = [], Dt = {}, Ct = [], Rt = 0, At = null, Yt = new WeakMap
                }(), xi(), vt = {}, mt = {}, yt = [], bt = [], yi(), wi(), Ni(), _t.clear()
        }
    }, {
        start: function() {
            ve = [], kr(), Ca(), Pa(), Va(), ja(), Q = !1, mo(window, "resize", $), Ja(), mo(document, "visibilitychange", ci), ci(), mo(window, "focus", (function() {
                    return di(1)
                })), mo(window, "blur", (function() {
                    return di(0)
                })),
                function() {
                    if (!ft) try {
                        window[Pn("addEventListener")]("pageshow", vo(fi), {
                            capture: !1,
                            passive: !0
                        }), ft = !0
                    } catch (t) {}
                }(), tt = [], Za(), ai(), Na(), ri(), mo(window, "pagehide", oi)
        },
        stop: function() {
            ve = [], kr(), Ca(), Pa(), ea(V), F.length > 0 && Fa(F[F.length - 1].event), ea(U), ja(), Ga(), li(), si(), ea(at), it.cleanup(), tt = [], et = null, nt = null, ai(), ea(ut), Na(), ri(), ui()
        }
    }, {
        start: function() {
            Oo(),
                function() {
                    navigator && navigator.connection && Kr(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? mo(window, "load", ta.bind(this, Io, 0)) : Io() : Pr(3, 0)
                }()
        },
        stop: function() {
            Mn && Mn.disconnect(), Mn = null, Tn(), On = null, Oo()
        }
    }, {
        start: function() {
            Se = !0, Ee = new Set, An.modules && An.modules.length > 0 && An.modules.forEach((function(t) {
                Mr(t)
            }))
        },
        stop: function() {
            ke.reverse().forEach((function(t) {
                try {
                    t()
                } catch (t) {}
            })), ke = [], Se = !1
        }
    }], In = {
        __proto__: null,
        consent: function(t) {
            void 0 === t && (t = !0), no(t ? {
                source: 4,
                ad_Storage: "granted",
                analytics_Storage: "granted"
            } : {
                source: 4,
                ad_Storage: "denied",
                analytics_Storage: "denied"
            })
        },
        consentv2: no,
        dlog: Kr,
        event: Kn,
        hashText: ir,
        identify: function(t, e, n, a) {
            return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), aa(this, void 0, void 0, (function() {
                var i, r;
                return ia(this, (function(o) {
                    switch (o.label) {
                        case 0:
                            return r = {}, [4, la(t)];
                        case 1:
                            return r.userId = o.sent(), r.userHint = a || ((u = t) && u.length >= 5 ? u.substring(0, 2) + qn(u.substring(2), "*", "*") : qn(u, "*", "*")), ua("userId", [(i = r).userId]), ua("userHint", [i.userHint]), ua("userType", [sa(t)]), e && (ua("sessionId", [e]), i.sessionId = e), n && (ua("pageId", [n]), i.pageId = n), [2, i]
                    }
                    var u
                }))
            }))
        },
        maxMetric: $n,
        measure: vo,
        metadata: function(t, e, n, a) {
            var i, r;
            void 0 === e && (e = !0), void 0 === n && (n = !1), void 0 === a && (a = !1), i = An.lean ? 0 : 1, r = !1, Qe && (i || !1 === e) && (t(Qe, !An.lean, a ? en : void 0), r = !0), !n && r || $e.push({
                callback: t,
                wait: e,
                recall: n,
                called: r,
                consentInfo: a
            })
        },
        pause: function() {
            Mo() && (Kn("clarity", "pause"), null === qe && (qe = new Promise((function(t) {
                Ue = t
            }))))
        },
        queue: _r,
        register: function(t) {
            Se && "function" == typeof t && ke.push(t)
        },
        resume: function() {
            Mo() && (qe && (Ue(), qe = null, null === He && Yr()), Kn("clarity", "resume"))
        },
        schedule: Lr,
        set: oa,
        signal: function(t) {
            x = t
        },
        start: Ao,
        stop: Po,
        time: Ln,
        upgrade: Vr,
        version: e
    }, Dn = window, Cn = "clarity", Ro()
}();